============================================================
  SYBCA-AI (Sem-III) | 303 Machine Learning
  Mini Project: E-Commerce Return Prediction System
============================================================

PROJECT OVERVIEW:
-----------------
Title     : E-Commerce Return Prediction Using Machine Learning
Domain    : E-Commerce & Retail Analytics
Dataset   : 1,000 order transaction records (orders.csv)
Target    : is_returned (0 = Not Returned, 1 = Returned)
Type      : Supervised Machine Learning — Classification
Algorithms: Logistic Regression (Baseline), Decision Tree, Random Forest

HOW TO RUN (in order):
-----------------------
Step 1:  cd Python_Code
Step 2:  pip install -r ../requirements.txt

Run each practical file in order:
  python practical_1_project_proposal.py
  python practical_2_dataset_collection.py
  python practical_3_understanding_data.py
  python practical_4_eda.py                       ← generates EDA charts in Reports/
  python practical_5_handle_missing_outliers.py   ← generates orders_clean.csv & outlier plot
  python practical_6_automated_eda.py             ← generates EDA_Report.html
  python practical_7_feature_selection.py         ← generates split_data.pkl & correlation plot
  python practical_8_model_building.py            ← generates model_results.pkl
  python practical_9_model_evaluation.py          ← generates confusion_matrix & roc_curve
  python practical_10_improve_model.py            ← generates model_comparison.csv & best_model.joblib
  python practical_11_results_conclusion.py       ← generates predictions.csv & final conclusion

INTERACTIVE WEB APPLICATION (Streamlit):
----------------------------------------
To launch the interactive prediction dashboard:
  cd ..
  streamlit run app.py

FOLDER STRUCTURE:
-----------------
E_Commerce_Return_Prediction/
├── Dataset/
│   ├── orders.csv                 ← original 1,000-record dataset
│   ├── orders_clean.csv           ← generated after Practical 5
│   ├── split_data.pkl             ← generated after Practical 7
│   └── model_results.pkl          ← generated after Practical 8
├── Python_Code/
│   ├── practical_1_project_proposal.py
│   ├── practical_2_dataset_collection.py
│   ├── practical_3_understanding_data.py
│   ├── practical_4_eda.py
│   ├── practical_5_handle_missing_outliers.py
│   ├── practical_6_automated_eda.py
│   ├── practical_7_feature_selection.py
│   ├── practical_8_model_building.py
│   ├── practical_9_model_evaluation.py
│   ├── practical_10_improve_model.py
│   ├── practical_11_results_conclusion.py
│   ├── data_preprocessing.py      ← modular data pipeline
│   ├── eda.py                     ← modular EDA visualizer
│   ├── train_model.py             ← modular model trainer
│   ├── evaluate_model.py          ← modular model evaluator
│   └── predict.py                 ← CLI interactive predictor
├── models/
│   └── best_model.joblib          ← saved best model & scaler
├── Reports/
│   ├── EDA_Report.html            ← generated after Practical 6
│   ├── histogram.png
│   ├── boxplot.png
│   ├── pie_chart.png
│   ├── bar_chart.png
│   ├── correlation_matrix.png
│   ├── before_after_outliers.png
│   ├── feature_correlation.png
│   ├── confusion_matrix.png
│   ├── roc_curve.png
│   ├── model_comparison.png
│   └── feature_importance.png
├── Results/
│   ├── model_comparison.csv
│   ├── confusion_matrix.png
│   └── predictions.csv
├── app.py                         ← Streamlit Web Application
├── requirements.txt
├── README.md
└── README.txt
============================================================
