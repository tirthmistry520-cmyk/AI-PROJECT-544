# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 9 — Model Evaluation (Classification Metrics)
# ============================================================
#  Unit Covered : Unit-3 & Unit-4
# ============================================================

import os
import sys
import pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix, classification_report
)

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'model_results.pkl')
REPORTS_DIR = os.path.join(SCRIPT_DIR, '..', 'Reports')
RESULTS_DIR = os.path.join(SCRIPT_DIR, '..', 'Results')
os.makedirs(REPORTS_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

with open(RESULTS_PATH, 'rb') as f:
    model, y_pred, y_prob, y_test, X_train_scaled, X_test_scaled, FEATURES = pickle.load(f)

print("=" * 65)
print("PRACTICAL 9 : Model Evaluation (Classification Metrics)")
print("=" * 65)

# ── 1. Compute Primary Classification Metrics ─────────────
acc   = accuracy_score(y_test, y_pred)
prec  = precision_score(y_test, y_pred, zero_division=0)
rec   = recall_score(y_test, y_pred, zero_division=0)
f1    = f1_score(y_test, y_pred, zero_division=0)
auc   = roc_auc_score(y_test, y_prob)

cm = confusion_matrix(y_test, y_pred)
tn, fp, fn, tp = cm.ravel()
specificity = tn / (tn + fp) if (tn + fp) > 0 else 0

print(f"\n  Classification Performance Metrics:")
print(f"  -----------------------------------")
print(f"  Accuracy           : {acc:.4f}  ({acc*100:.2f}%)")
print(f"  Precision          : {prec:.4f}  ({prec*100:.2f}%)")
print(f"  Recall/Sensitivity : {rec:.4f}  ({rec*100:.2f}%)")
print(f"  Specificity        : {specificity:.4f}  ({specificity*100:.2f}%)")
print(f"  F1-Score           : {f1:.4f}")
print(f"  ROC-AUC Score      : {auc:.4f}")

print("\nDetailed Classification Report:")
print(classification_report(y_test, y_pred, target_names=['Not Returned (0)', 'Returned (1)']))

print("\nMetric Interpretation:")
print(f"  -> Accuracy ({acc*100:.1f}%): Overall percentage of correct order classifications.")
print(f"  -> Recall ({rec*100:.1f}%): Proportion of actual returns correctly caught by the model.")
print(f"  -> Precision ({prec*100:.1f}%): Proportion of predicted returns that were truly returned.")
print(f"  -> ROC-AUC ({auc:.3f}): Model discriminative ability between returned vs kept orders.")

# ── 2. Confusion Matrix Plot ──────────────────────────────
fig, ax = plt.subplots(figsize=(7, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False,
            xticklabels=['Pred: Not Returned', 'Pred: Returned'],
            yticklabels=['Actual: Not Returned', 'Actual: Returned'],
            annot_kws={'size': 14, 'weight': 'bold'}, ax=ax)
ax.set_title('Confusion Matrix - Logistic Regression', fontsize=14, fontweight='bold', pad=12)
ax.set_ylabel('True Class', fontsize=12)
ax.set_xlabel('Predicted Class', fontsize=12)
plt.tight_layout()

cm_rep_path = os.path.join(REPORTS_DIR, 'confusion_matrix.png')
cm_res_path = os.path.join(RESULTS_DIR, 'confusion_matrix.png')
plt.savefig(cm_rep_path, dpi=150, bbox_inches='tight')
plt.savefig(cm_res_path, dpi=150, bbox_inches='tight')
plt.close(fig)
print(f"\n  [OK] Saved: Reports/confusion_matrix.png & Results/confusion_matrix.png")

# ── 3. ROC Curve Plot ─────────────────────────────────────
fpr, tpr, thresholds = roc_curve(y_test, y_prob)

plt.figure(figsize=(7, 6))
plt.plot(fpr, tpr, color='#0984e3', lw=2.5, label=f'Logistic Regression (AUC = {auc:.3f})')
plt.plot([0, 1], [0, 1], color='#d63031', lw=1.8, linestyle='--', label='Random Chance (AUC = 0.500)')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate (1 - Specificity)', fontsize=11)
plt.ylabel('True Positive Rate (Recall)', fontsize=11)
plt.title('Receiver Operating Characteristic (ROC) Curve', fontsize=13, fontweight='bold')
plt.legend(loc="lower right", fontsize=11)
plt.grid(True, linestyle=':', alpha=0.6)
plt.tight_layout()

roc_path = os.path.join(REPORTS_DIR, 'roc_curve.png')
plt.savefig(roc_path, dpi=150, bbox_inches='tight')
plt.close()
print(f"  [OK] Saved: Reports/roc_curve.png")

# ── 4. Feature Importance (Logistic Regression Weights) ───
coef_series = pd.Series(model.coef_[0], index=FEATURES).sort_values()
plt.figure(figsize=(9, 5))
bar_colors = ['#2ecc71' if c >= 0 else '#e74c3c' for c in coef_series]
coef_series.plot(kind='barh', color=bar_colors, edgecolor='black')
plt.axvline(0, color='black', lw=0.8)
plt.title('Feature Coefficients (Impact on Return Odds)', fontsize=13, fontweight='bold')
plt.xlabel('Coefficient Value')
plt.tight_layout()

feat_imp_path = os.path.join(REPORTS_DIR, 'feature_importance.png')
plt.savefig(feat_imp_path, dpi=150, bbox_inches='tight')
plt.close()
print(f"  [OK] Saved: Reports/feature_importance.png")

print("\n" + "=" * 65)
print("[OK] Practical 9 completed successfully.")
