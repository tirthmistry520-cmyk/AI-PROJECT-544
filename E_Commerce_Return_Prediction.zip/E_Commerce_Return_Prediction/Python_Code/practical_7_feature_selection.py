# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 7 — Feature Selection & Train-Test Split
# ============================================================
#  Unit Covered : Unit-3
# ============================================================

import os
import sys
import pickle
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'orders_clean.csv')
SPLIT_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'split_data.pkl')
REPORTS_DIR = os.path.join(SCRIPT_DIR, '..', 'Reports')
os.makedirs(REPORTS_DIR, exist_ok=True)

df = pd.read_csv(DATA_PATH)

print("=" * 65)
print("PRACTICAL 7 : Feature Engineering, Selection & Split")
print("=" * 65)

# ── 1. Feature Engineering ────────────────────────────────
print("\n[1] Engineering Date-Time & Behavioral Features...")
df['order_date'] = pd.to_datetime(df['order_date'])

df['month']       = df['order_date'].dt.month
df['day']         = df['order_date'].dt.day
df['day_of_week'] = df['order_date'].dt.day_of_week
df['hour']        = df['order_date'].dt.hour
df['is_weekend']  = (df['day_of_week'] >= 5).astype(int)
df['amount_log']  = np.log1p(df['total_amount'])

# Define Target Variable
TARGET = 'is_returned'
df[TARGET] = (df['order_status'].str.lower() == 'returned').astype(int)

# Feature Selection: Exclude identifiers (order_id, user_id) to avoid overfitting
# Exclude original order_status to avoid target leakage
FEATURES = ['total_amount', 'amount_log', 'month', 'day', 'day_of_week', 'hour', 'is_weekend']

print(f"  Target Variable   : {TARGET} (0 = Not Returned, 1 = Returned)")
print(f"  Feature Set ({len(FEATURES)}) : {FEATURES}")

X = df[FEATURES]
y = df[TARGET]

# ── 2. Feature Correlation with Target ────────────────────
print("\n[2] Computing Pearson Correlation with Target:")
corr_target = df[FEATURES + [TARGET]].corr()[TARGET].drop(TARGET).sort_values(ascending=False)
for feat, val in corr_target.items():
    print(f"    {feat:<16}: {val:>8.4f}")

# Plot feature correlations
plt.figure(figsize=(9, 5))
colors = ['#2ecc71' if v >= 0 else '#e74c3c' for v in corr_target]
corr_target.plot(kind='barh', color=colors, edgecolor='black')
plt.axvline(0, color='black', linewidth=0.8, linestyle='--')
plt.title('Feature Correlation with Target (is_returned)', fontsize=13, fontweight='bold')
plt.xlabel('Correlation Coefficient')
plt.ylabel('Features')
plt.tight_layout()
feat_corr_path = os.path.join(REPORTS_DIR, 'feature_correlation.png')
plt.savefig(feat_corr_path, dpi=150, bbox_inches='tight')
plt.close()
print(f"  Saved: Reports/feature_correlation.png")

# ── 3. Train-Test Split (80:20 with Stratification) ───────
print("\n[3] Splitting Data into 80% Train & 20% Test Sets...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# Standard Scaling for feature normalization
scaler = StandardScaler()
X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=FEATURES, index=X_train.index)
X_test_scaled  = pd.DataFrame(scaler.transform(X_test), columns=FEATURES, index=X_test.index)

print(f"  Total Clean Records  : {len(df):,}")
print(f"  Training Set (80%)   : {X_train.shape[0]:,} samples")
print(f"  Testing Set  (20%)   : {X_test.shape[0]:,} samples")
print(f"  Feature Dimensions   : {X_train.shape[1]}")
print(f"  Train Target Balance : Returned = {y_train.sum()} ({y_train.mean()*100:.2f}%)")
print(f"  Test Target Balance  : Returned = {y_test.sum()} ({y_test.mean()*100:.2f}%)")

# ── 4. Save Processed Split Data ──────────────────────────
with open(SPLIT_PATH, 'wb') as f:
    pickle.dump((X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler, FEATURES, TARGET), f)

print(f"\n[OK] Split data saved successfully -> Dataset/split_data.pkl")
print("=" * 65)
print("[OK] Practical 7 completed successfully.")
