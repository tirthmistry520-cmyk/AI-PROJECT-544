# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 10 — Improve Model (CV + Algorithm Comparison)
# ============================================================
#  Unit Covered : Unit-4
# ============================================================

import os
import sys
import pickle
import numpy as np
import pandas as pd
import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
)

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SPLIT_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'split_data.pkl')
REPORTS_DIR = os.path.join(SCRIPT_DIR, '..', 'Reports')
RESULTS_DIR = os.path.join(SCRIPT_DIR, '..', 'Results')
MODELS_DIR = os.path.join(SCRIPT_DIR, '..', 'models')
os.makedirs(REPORTS_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

with open(SPLIT_PATH, 'rb') as f:
    X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler, FEATURES, TARGET = pickle.load(f)

print("=" * 65)
print("PRACTICAL 10 : Improve Model - CV & Multi-Algorithm Comparison")
print("=" * 65)

# Combined data for cross-validation
X_all_scaled = pd.concat([X_train_scaled, X_test_scaled])
y_all = pd.concat([y_train, y_test])
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Define candidates
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42, class_weight='balanced'),
    'Decision Tree': DecisionTreeClassifier(max_depth=5, min_samples_leaf=20, random_state=42, class_weight='balanced'),
    'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, class_weight='balanced', n_jobs=-1)
}

comparison_records = []
fitted_models = {}

print("\nTraining and cross-validating candidate algorithms...")
for name, clf in models.items():
    print(f"\n[Algorithm] {name}")
    # 5-fold cross validation
    cv_roc = cross_val_score(clf, X_all_scaled, y_all, cv=cv, scoring='roc_auc')
    cv_f1  = cross_val_score(clf, X_all_scaled, y_all, cv=cv, scoring='f1')
    print(f"  5-Fold CV ROC-AUC: {cv_roc.mean():.4f} (+/-{cv_roc.std():.4f})")
    print(f"  5-Fold CV F1-Score: {cv_f1.mean():.4f} (+/-{cv_f1.std():.4f})")
    
    # Train on training set
    clf.fit(X_train_scaled, y_train)
    fitted_models[name] = clf
    
    # Evaluate on test set
    y_pred = clf.predict(X_test_scaled)
    y_prob = clf.predict_proba(X_test_scaled)[:, 1] if hasattr(clf, "predict_proba") else y_pred
    
    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec  = recall_score(y_test, y_pred, zero_division=0)
    f1   = f1_score(y_test, y_pred, zero_division=0)
    auc  = roc_auc_score(y_test, y_prob)
    
    comparison_records.append({
        'Model': name,
        'Accuracy': acc,
        'Precision': prec,
        'Recall': rec,
        'F1_Score': f1,
        'ROC_AUC': auc,
        'CV_ROC_AUC_Mean': cv_roc.mean(),
        'CV_F1_Mean': cv_f1.mean()
    })

comparison_df = pd.DataFrame(comparison_records)

# ── Display Formatted Comparison Table ─────────────────────
print("\n" + "=" * 65)
print("ALGORITHM COMPARISON TABLE")
print("=" * 65)
print(f"{'Model':<22} {'Accuracy':>9} {'Precision':>10} {'Recall':>8} {'F1':>8} {'ROC-AUC':>9} {'CV AUC':>9}")
print("-" * 77)
for _, r in comparison_df.iterrows():
    print(f"{r['Model']:<22} {r['Accuracy']:>9.4f} {r['Precision']:>10.4f} {r['Recall']:>8.4f} {r['F1_Score']:>8.4f} {r['ROC_AUC']:>9.4f} {r['CV_ROC_AUC_Mean']:>9.4f}")
print("=" * 77)

# Save comparison table to CSV
comp_csv_path = os.path.join(RESULTS_DIR, 'model_comparison.csv')
comparison_df.to_csv(comp_csv_path, index=False)
print(f"[OK] Model comparison saved -> Results/model_comparison.csv")

# ── Identify & Save Best Model ────────────────────────────
best_model_row = comparison_df.sort_values(by=['ROC_AUC', 'F1_Score'], ascending=False).iloc[0]
best_model_name = best_model_row['Model']
best_model_obj = fitted_models[best_model_name]

print(f"\n[*] BEST PERFORMING MODEL: {best_model_name}")
print(f"    Test ROC-AUC = {best_model_row['ROC_AUC']:.4f} | F1-Score = {best_model_row['F1_Score']:.4f}")

model_export = {
    'model': best_model_obj,
    'model_name': best_model_name,
    'scaler': scaler,
    'features': FEATURES,
    'metrics': best_model_row.to_dict()
}
best_model_path = os.path.join(MODELS_DIR, 'best_model.joblib')
joblib.dump(model_export, best_model_path)
print(f"[OK] Best model artifact saved -> models/best_model.joblib")

# ── Plot Comparison Chart ─────────────────────────────────
metrics_to_plot = ['Accuracy', 'Precision', 'Recall', 'F1_Score', 'ROC_AUC']
x = np.arange(len(comparison_df))
bar_width = 0.16

fig, ax = plt.subplots(figsize=(12, 6))
colors = ['#3498db', '#2ecc71', '#e67e22', '#e74c3c', '#9b59b6']

for i, metric in enumerate(metrics_to_plot):
    offsets = x + (i - len(metrics_to_plot) / 2 + 0.5) * bar_width
    bars = ax.bar(offsets, comparison_df[metric], bar_width, label=metric, color=colors[i], edgecolor='black')

ax.set_title('Algorithm Comparison Across Key Evaluation Metrics', fontsize=14, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(comparison_df['Model'], fontsize=11, fontweight='bold')
ax.set_ylabel('Score (0.0 to 1.0)', fontsize=11)
ax.set_ylim(0, 1.05)
ax.legend(loc='lower right', fontsize=10)
ax.grid(axis='y', linestyle=':', alpha=0.6)
plt.tight_layout()

chart_path = os.path.join(REPORTS_DIR, 'model_comparison.png')
plt.savefig(chart_path, dpi=150, bbox_inches='tight')
plt.close(fig)
print(f"[OK] Saved: Reports/model_comparison.png")

print("\n" + "=" * 65)
print("[OK] Practical 10 completed successfully.")
