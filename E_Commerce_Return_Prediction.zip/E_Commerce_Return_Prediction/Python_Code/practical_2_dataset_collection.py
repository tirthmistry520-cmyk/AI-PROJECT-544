# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 2 — Dataset Collection & Description
# ============================================================
#  Unit Covered : Unit-1
# ============================================================

import os
import sys
import pandas as pd

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# Path resolution to ensure script runs from any working directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'orders.csv')

df = pd.read_csv(DATA_PATH)

print("=" * 65)
print("PRACTICAL 2 : Dataset Collection & Description")
print("=" * 65)

print(f"\nDataset Shape: {df.shape[0]} rows x {df.shape[1]} columns")
print("\nFirst 5 Records:")
print(df.head())

print("\n" + "=" * 65)
print("COLUMN DESCRIPTIONS")
print("=" * 65)
info = {
    'order_id'    : 'Unique alphanumeric order identifier  [Identifier]',
    'user_id'     : 'Unique customer identifier            [Identifier]',
    'order_date'  : 'Timestamp of order placement (ISO)    [Datetime/Temporal]',
    'order_status': 'Recorded status of fulfillment        [Categorical - Source]',
    'total_amount': 'Total order invoice amount (Rs./USD)  [Numerical/Continuous]'
}

for col, desc in info.items():
    print(f"  {col:<16}: {desc}")

print("\n" + "=" * 65)
print("ORIGINAL ORDER STATUS DISTRIBUTION")
print("=" * 65)
status_counts = df['order_status'].value_counts()
status_pct = df['order_status'].value_counts(normalize=True) * 100
status_summary = pd.DataFrame({'Count': status_counts, 'Percentage (%)': status_pct.round(2)})
print(status_summary)

print("\n" + "=" * 65)
print("TARGET & FEATURE FORMULATION")
print("=" * 65)
ret_cnt = (df['order_status'] == 'returned').sum()
non_ret_cnt = len(df) - ret_cnt
ret_pct = (ret_cnt / len(df)) * 100
non_ret_pct = 100.0 - ret_pct

print("  [*] TARGET VARIABLE  : is_returned (Derived from order_status == 'returned')")
print(f"                         1 = Returned  ({ret_cnt:,} orders | ~{ret_pct:.2f}%)")
print(f"                         0 = Not Returned / Other ({non_ret_cnt:,} orders | ~{non_ret_pct:.2f}%)")
print("  [*] FEATURE INPUTS   : total_amount + datetime features (month, day, weekday, hour)")
print("  [*] EXCLUDED COLUMNS : order_id, user_id (Identifiers - prevent overfitting)")
print("                         order_status (Source column - excluded to prevent data leakage)")
print("=" * 65)
print("[OK] Practical 2 completed successfully.")
