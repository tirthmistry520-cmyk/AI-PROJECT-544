"""
=============================================================================
Module: Model Evaluation Module
Project: E-Commerce Return Prediction Using Machine Learning
=============================================================================
"""

import os
import pickle
import joblib
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SPLIT_PATH = os.path.join(BASE_DIR, '..', 'Dataset', 'split_data.pkl')
MODELS_PATH = os.path.join(BASE_DIR, '..', 'models', 'best_model.joblib')
RESULTS_DIR = os.path.join(BASE_DIR, '..', 'Results')

def evaluate_best_model():
    with open(SPLIT_PATH, 'rb') as f:
        X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler, features, target = pickle.load(f)
        
    pkg = joblib.load(MODELS_PATH)
    model = pkg['model']
    model_name = pkg['model_name']
    
    y_pred = model.predict(X_test_scaled)
    y_prob = model.predict_proba(X_test_scaled)[:, 1] if hasattr(model, "predict_proba") else y_pred
    
    print("=" * 60)
    print(f"EVALUATING MODEL: {model_name}")
    print("=" * 60)
    print(classification_report(y_test, y_pred, target_names=['Not Returned', 'Returned']))
    
    cm = confusion_matrix(y_test, y_pred)
    print("Confusion Matrix:")
    print(cm)
    
    auc = roc_auc_score(y_test, y_prob)
    print(f"ROC-AUC Score: {auc:.4f}")

if __name__ == '__main__':
    evaluate_best_model()
