"""
=============================================================================
Module: Model Training Pipeline
Project: E-Commerce Return Prediction Using Machine Learning
=============================================================================
"""

import os
import sys
import pickle
import joblib
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SPLIT_PATH = os.path.join(BASE_DIR, '..', 'Dataset', 'split_data.pkl')
MODELS_DIR = os.path.join(BASE_DIR, '..', 'models')
RESULTS_DIR = os.path.join(BASE_DIR, '..', 'Results')

def train_and_select_best():
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)
    
    with open(SPLIT_PATH, 'rb') as f:
        X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler, features, target = pickle.load(f)
        
    candidates = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42, class_weight='balanced'),
        'Decision Tree': DecisionTreeClassifier(max_depth=5, min_samples_leaf=20, random_state=42, class_weight='balanced'),
        'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, class_weight='balanced', n_jobs=-1)
    }
    
    results = []
    best_auc = -1
    best_entry = None
    
    for name, clf in candidates.items():
        clf.fit(X_train_scaled, y_train)
        pred = clf.predict(X_test_scaled)
        prob = clf.predict_proba(X_test_scaled)[:, 1] if hasattr(clf, "predict_proba") else pred
        
        acc = accuracy_score(y_test, pred)
        rec = recall_score(y_test, pred, zero_division=0)
        prec = precision_score(y_test, pred, zero_division=0)
        f1 = f1_score(y_test, pred, zero_division=0)
        auc = roc_auc_score(y_test, prob)
        
        entry = {
            'Model': name,
            'Accuracy': acc,
            'Precision': prec,
            'Recall': rec,
            'F1_Score': f1,
            'ROC_AUC': auc
        }
        results.append(entry)
        print(f"[{name}] Acc={acc:.4f} | Prec={prec:.4f} | Rec={rec:.4f} | F1={f1:.4f} | AUC={auc:.4f}")
        
        if auc > best_auc:
            best_auc = auc
            best_entry = (name, clf, entry)
            
    # Save best model
    best_name, best_clf, best_metrics = best_entry
    export_pkg = {
        'model': best_clf,
        'model_name': best_name,
        'scaler': scaler,
        'features': features,
        'metrics': best_metrics
    }
    joblib.dump(export_pkg, os.path.join(MODELS_DIR, 'best_model.joblib'))
    pd.DataFrame(results).to_csv(os.path.join(RESULTS_DIR, 'model_comparison.csv'), index=False)
    print(f"\n[OK] Best Model: {best_name} saved to models/best_model.joblib")

if __name__ == '__main__':
    train_and_select_best()
