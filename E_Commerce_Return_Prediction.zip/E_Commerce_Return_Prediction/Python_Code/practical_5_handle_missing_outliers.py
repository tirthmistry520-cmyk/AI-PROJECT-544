# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 5 — Handle Missing Values & Outliers
# ============================================================
#  Unit Covered : Unit-2
# ============================================================

import os
import sys
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'orders.csv')
CLEAN_DATA_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'orders_clean.csv')
REPORTS_DIR = os.path.join(SCRIPT_DIR, '..', 'Reports')
os.makedirs(REPORTS_DIR, exist_ok=True)

df = pd.read_csv(DATA_PATH)
numerical_cols   = df.select_dtypes(include=[np.number]).columns.tolist()
categorical_cols = [c for c in df.columns if c not in numerical_cols]

print("=" * 65)
print("PRACTICAL 5 : Handle Missing Values & Outliers")
print("=" * 65)

print(f"\n[BEFORE] Total Records  : {len(df):,}")
print(f"[BEFORE] Missing Cells  : {df.isnull().sum().sum()}")
print(f"[BEFORE] Duplicate Rows : {df.duplicated().sum()}")
print(f"[BEFORE] Amount Range   : Rs.{df['total_amount'].min():.2f} - Rs.{df['total_amount'].max():.2f}")

# ── 1. Handle Missing Values ──────────────────────────────
missing_fixed = 0
for col in numerical_cols:
    if df[col].isnull().sum() > 0:
        med_val = df[col].median()
        df[col] = df[col].fillna(med_val)
        print(f"  [OK] Imputed '{col}' with median: {med_val:.2f}")
        missing_fixed += 1

for col in categorical_cols:
    if df[col].isnull().sum() > 0:
        mode_val = df[col].mode()[0]
        df[col] = df[col].fillna(mode_val)
        print(f"  [OK] Imputed '{col}' with mode: {mode_val}")
        missing_fixed += 1

if missing_fixed == 0:
    print("  [INFO] No missing values detected in the original dataset.")

# ── 2. Handle Duplicate Records ───────────────────────────
dup_count = df.duplicated().sum()
if dup_count > 0:
    df = df.drop_duplicates()
    print(f"  [OK] Removed {dup_count} duplicate rows.")
else:
    print("  [INFO] Zero duplicate rows found.")

# ── 3. Handle Outliers via Interquartile Range (IQR) ───────
Q1  = df['total_amount'].quantile(0.25)
Q3  = df['total_amount'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = max(0.0, Q1 - 1.5 * IQR)
upper_bound = Q3 + 1.5 * IQR

outlier_mask = (df['total_amount'] < lower_bound) | (df['total_amount'] > upper_bound)
outlier_count = outlier_mask.sum()

print(f"\n  IQR Outlier Analysis for 'total_amount':")
print(f"  -> 25th Percentile (Q1) : Rs.{Q1:.2f}")
print(f"  -> 75th Percentile (Q3) : Rs.{Q3:.2f}")
print(f"  -> IQR Value            : Rs.{IQR:.2f}")
print(f"  -> Lower Limit Bound    : Rs.{lower_bound:.2f}")
print(f"  -> Upper Limit Bound    : Rs.{upper_bound:.2f}")
print(f"  -> Detected Outliers    : {outlier_count:,} ({outlier_count/len(df)*100:.2f}%)")

# Filter out extreme anomalies beyond 1.5 * IQR for clean training
df_clean = df[(df['total_amount'] >= lower_bound) & (df['total_amount'] <= upper_bound)].copy()

print(f"\n[AFTER]  Clean Records  : {len(df_clean):,}")
print(f"[AFTER]  Missing Cells  : {df_clean.isnull().sum().sum()}")
print(f"[AFTER]  Amount Range   : Rs.{df_clean['total_amount'].min():.2f} - Rs.{df_clean['total_amount'].max():.2f}")

# ── 4. Generate Before vs After Outlier Plot ───────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('Before vs After Outlier Removal - total_amount', fontsize=14, fontweight='bold')

axes[0].boxplot(df['total_amount'], patch_artist=True,
                boxprops=dict(facecolor='#ff7675', color='black'),
                medianprops=dict(color='black', linewidth=2))
axes[0].set_title(f'BEFORE Treatment (n = {len(df):,})')
axes[0].set_ylabel('Total Amount (Rs./USD)')

axes[1].boxplot(df_clean['total_amount'], patch_artist=True,
                boxprops=dict(facecolor='#55efc4', color='black'),
                medianprops=dict(color='black', linewidth=2))
axes[1].set_title(f'AFTER Treatment (n = {len(df_clean):,})')
axes[1].set_ylabel('Total Amount (Rs./USD)')

plt.tight_layout()
outlier_plot_path = os.path.join(REPORTS_DIR, 'before_after_outliers.png')
plt.savefig(outlier_plot_path, dpi=150, bbox_inches='tight')
plt.close(fig)
print(f"\n  Saved: Reports/before_after_outliers.png")

# Save cleaned dataset
df_clean.to_csv(CLEAN_DATA_PATH, index=False)
print(f"[OK] Cleaned dataset saved -> Dataset/orders_clean.csv")
print("=" * 65)
print("[OK] Practical 5 completed successfully.")
