# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 4 — Exploratory Data Analysis (EDA)
# ============================================================
#  Unit Covered : Unit-1 & Unit-2
# ============================================================

import os
import sys
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Headless backend for automated execution and file saving
import matplotlib.pyplot as plt
import seaborn as sns

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'orders.csv')
REPORTS_DIR = os.path.join(SCRIPT_DIR, '..', 'Reports')
os.makedirs(REPORTS_DIR, exist_ok=True)

df = pd.read_csv(DATA_PATH)

# Feature extraction for rich EDA
df['order_date'] = pd.to_datetime(df['order_date'])
df['is_returned'] = (df['order_status'].str.lower() == 'returned').astype(int)
df['month'] = df['order_date'].dt.month
df['day'] = df['order_date'].dt.day
df['day_of_week'] = df['order_date'].dt.day_of_week
df['hour'] = df['order_date'].dt.hour
df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)

day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

print("=" * 65)
print("PRACTICAL 4 : Exploratory Data Analysis (EDA)")
print("=" * 65)

# ── 1. Histograms ─────────────────────────────────────────
print("\n[1] Generating Histograms...")
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Histograms - Feature Distributions', fontsize=16, fontweight='bold')

axes[0, 0].hist(df['total_amount'], bins=40, color='#3498db', edgecolor='black', alpha=0.8)
axes[0, 0].set_title('Order Total Amount Distribution (Rs./USD)', fontsize=12)
axes[0, 0].set_xlabel('Total Amount')
axes[0, 0].set_ylabel('Frequency')

axes[0, 1].hist(df['hour'], bins=24, range=(0, 24), color='#2ecc71', edgecolor='black', alpha=0.8)
axes[0, 1].set_title('Orders by Hour of Day (0 - 23)', fontsize=12)
axes[0, 1].set_xlabel('Hour')
axes[0, 1].set_ylabel('Frequency')

axes[1, 0].hist(df['month'], bins=12, range=(1, 13), color='#e67e22', edgecolor='black', alpha=0.8)
axes[1, 0].set_title('Orders by Month of Year (1 - 12)', fontsize=12)
axes[1, 0].set_xlabel('Month')
axes[1, 0].set_ylabel('Frequency')

axes[1, 1].hist(df['day_of_week'], bins=7, range=(0, 7), color='#9b59b6', edgecolor='black', alpha=0.8)
axes[1, 1].set_title('Orders by Day of Week (0=Mon to 6=Sun)', fontsize=12)
axes[1, 1].set_xlabel('Day of Week')
axes[1, 1].set_xticks(range(7))
axes[1, 1].set_xticklabels(day_names)
axes[1, 1].set_ylabel('Frequency')

plt.tight_layout()
hist_path = os.path.join(REPORTS_DIR, 'histogram.png')
plt.savefig(hist_path, dpi=150, bbox_inches='tight')
plt.close(fig)
print("   Saved: Reports/histogram.png")

# ── 2. Box Plots ──────────────────────────────────────────
print("\n[2] Generating Box Plots for Outlier Detection...")
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle('Box Plots - Outlier & Status Spread', fontsize=16, fontweight='bold')

# Box plot across all records
axes[0].boxplot(df['total_amount'], patch_artist=True,
                boxprops=dict(facecolor='#ff7675', color='black'),
                medianprops=dict(color='black', linewidth=2))
axes[0].set_title('Overall Total Amount Distribution', fontsize=12, fontweight='bold')
axes[0].set_ylabel('Total Amount (Rs./USD)')

# Box plot by order status
palette = {'shipped': '#74b9ff', 'returned': '#ff7675', 'completed': '#55efc4',
           'cancelled': '#ffeaa7', 'processing': '#a29bfe'}
sns.boxplot(x='order_status', y='total_amount', hue='order_status', data=df, ax=axes[1], palette=palette, legend=False)
axes[1].set_title('Total Amount by Order Status', fontsize=12, fontweight='bold')
axes[1].set_xlabel('Order Status')
axes[1].set_ylabel('Total Amount (Rs./USD)')

plt.tight_layout()
box_path = os.path.join(REPORTS_DIR, 'boxplot.png')
plt.savefig(box_path, dpi=150, bbox_inches='tight')
plt.close(fig)
print("   Saved: Reports/boxplot.png")

# ── 3. Pie Charts ─────────────────────────────────────────
print("\n[3] Generating Pie Charts...")
fig, axes = plt.subplots(1, 2, figsize=(15, 7))

# Original 5 statuses
status_colors = ['#74b9ff', '#ff7675', '#55efc4', '#ffeaa7', '#a29bfe']
df['order_status'].value_counts().plot.pie(
    ax=axes[0], autopct='%1.1f%%', startangle=140,
    colors=status_colors, explode=(0.02, 0.05, 0.02, 0.02, 0.02),
    shadow=True
)
axes[0].set_title('5-Class Order Status Distribution', fontsize=13, fontweight='bold')
axes[0].set_ylabel('')

# Target binary class
target_labels = ['Not Returned (0)', 'Returned (1)']
target_counts = [ (df['is_returned']==0).sum(), (df['is_returned']==1).sum() ]
axes[1].pie(
    target_counts, labels=target_labels, autopct='%1.1f%%',
    colors=['#0984e3', '#d63031'], startangle=90,
    explode=(0, 0.08), shadow=True
)
axes[1].set_title('Binary Target Distribution (is_returned)', fontsize=13, fontweight='bold')
axes[1].set_ylabel('')

plt.tight_layout()
pie_path = os.path.join(REPORTS_DIR, 'pie_chart.png')
plt.savefig(pie_path, dpi=150, bbox_inches='tight')
plt.close(fig)
print("   Saved: Reports/pie_chart.png")

# ── 4. Bar Charts ─────────────────────────────────────────
print("\n[4] Generating Bar Charts...")
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
fig.suptitle('Bar Charts - Order & Return Analytics', fontsize=16, fontweight='bold')

# Mean amount by status
avg_amount = df.groupby('order_status')['total_amount'].mean().sort_values(ascending=False)
avg_amount.plot(kind='bar', ax=axes[0, 0], color='#00cec9', edgecolor='black')
axes[0, 0].set_title('Average Order Amount by Status', fontweight='bold')
axes[0, 0].set_xlabel('Order Status')
axes[0, 0].set_ylabel('Mean Total Amount (Rs.)')
axes[0, 0].tick_params(axis='x', rotation=15)

# Return rate by weekday
return_by_dow = (df.groupby('day_of_week')['is_returned'].mean() * 100)
return_by_dow.index = day_names
return_by_dow.plot(kind='bar', ax=axes[0, 1], color='#e17055', edgecolor='black')
axes[0, 1].set_title('Return Rate (%) by Day of Week', fontweight='bold')
axes[0, 1].set_xlabel('Day of Week')
axes[0, 1].set_ylabel('Return Rate (%)')
axes[0, 1].axhline(df['is_returned'].mean() * 100, color='blue', linestyle='--', label='Average Rate')
axes[0, 1].legend()

# Monthly order volume
monthly_orders = df.groupby('month')['order_id'].count()
monthly_orders.plot(kind='bar', ax=axes[1, 0], color='#6c5ce7', edgecolor='black')
axes[1, 0].set_title('Total Order Volume by Month', fontweight='bold')
axes[1, 0].set_xlabel('Month')
axes[1, 0].set_ylabel('Number of Orders')
axes[1, 0].tick_params(axis='x', rotation=0)

# Return rate by hour
return_by_hour = (df.groupby('hour')['is_returned'].mean() * 100)
return_by_hour.plot(kind='bar', ax=axes[1, 1], color='#fdcb6e', edgecolor='black')
axes[1, 1].set_title('Return Rate (%) by Hour of Day', fontweight='bold')
axes[1, 1].set_xlabel('Hour of Day (0-23)')
axes[1, 1].set_ylabel('Return Rate (%)')

plt.tight_layout()
bar_path = os.path.join(REPORTS_DIR, 'bar_chart.png')
plt.savefig(bar_path, dpi=150, bbox_inches='tight')
plt.close(fig)
print("   Saved: Reports/bar_chart.png")

# ── 5. Correlation Heatmap ────────────────────────────────
print("\n[5] Generating Correlation Heatmap...")
plt.figure(figsize=(10, 8))
corr_features = ['total_amount', 'month', 'day', 'day_of_week', 'hour', 'is_weekend', 'is_returned']
corr = df[corr_features].corr()
sns.heatmap(corr, annot=True, fmt='.3f', cmap='coolwarm', square=True,
            linewidths=0.5, cbar_kws={"shrink": 0.8})
plt.title('Correlation Matrix - Features vs is_returned', fontsize=14, fontweight='bold')
plt.tight_layout()
corr_path = os.path.join(REPORTS_DIR, 'correlation_matrix.png')
plt.savefig(corr_path, dpi=150, bbox_inches='tight')
plt.close()
print("   Saved: Reports/correlation_matrix.png")

print("\n" + "=" * 65)
print("[OK] EDA complete. All 5 visual reports saved in Reports/ directory.")
print("=" * 65)
