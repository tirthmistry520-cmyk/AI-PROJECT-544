"""
=============================================================================
Environment & Dependency Verifier
Project: E-Commerce Return Prediction System (SYBCA-AI 303 Machine Learning)
=============================================================================
"""

import os
import sys
import importlib.metadata

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REQ_FILE = os.path.join(SCRIPT_DIR, '..', 'requirements.txt')

def parse_requirements():
    reqs = []
    if os.path.exists(REQ_FILE):
        with open(REQ_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '>=' in line:
                    pkg, v = line.split('>=', 1)
                    reqs.append((pkg.strip(), v.strip()))
                elif '==' in line:
                    pkg, v = line.split('==', 1)
                    reqs.append((pkg.strip(), v.strip()))
                else:
                    reqs.append((line.strip(), 'Any'))
    else:
        reqs = [
            ('numpy', '1.26.0'),
            ('pandas', '2.0.0'),
            ('scipy', '1.11.0'),
            ('matplotlib', '3.8.0'),
            ('seaborn', '0.13.0'),
            ('scikit-learn', '1.3.0'),
            ('joblib', '1.3.0'),
            ('sweetviz', '2.3.0'),
            ('streamlit', '1.30.0'),
            ('plotly', '5.18.0'),
        ]
    return reqs

def check_all():
    reqs = parse_requirements()
    all_ok = True
    
    print("=" * 65)
    print("  PYTHON ENVIRONMENT & DEPENDENCY STATUS CHECK")
    print("=" * 65)
    print(f"  Python Version : {sys.version.split()[0]} ({sys.executable})")
    
    # Check pip
    try:
        pip_v = importlib.metadata.version('pip')
        print(f"  Pip Version    : {pip_v} [OK]")
    except Exception:
        print("  Pip Version    : Not Found [!] ")
        all_ok = False
        
    print("-" * 65)
    print(f"  {'Package':<18} {'Required':<12} {'Installed':<16} {'Status'}")
    print("-" * 65)
    
    for pkg, min_v in reqs:
        try:
            installed_v = importlib.metadata.version(pkg)
            status = "[OK]"
        except importlib.metadata.PackageNotFoundError:
            installed_v = "Not Installed"
            status = "[MISSING]"
            all_ok = False
        except Exception:
            installed_v = "Unknown"
            status = "[ERROR]"
            all_ok = False
            
        req_str = f">={min_v}" if min_v != "Any" else "Any"
        print(f"  {pkg:<18} {req_str:<12} {installed_v:<16} {status}")
        
    print("-" * 65)
    if all_ok:
        print("  [✓] All required packages are successfully installed & verified!")
    else:
        print("  [!] Some dependencies are missing. Run config.bat to install them.")
    print("=" * 65)
    
    return 0 if all_ok else 1

if __name__ == '__main__':
    code = check_all()
    sys.exit(code)
