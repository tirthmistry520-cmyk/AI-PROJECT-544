"""
=============================================================================
Module: Data Preprocessing & Feature Engineering Pipeline
Project: E-Commerce Return Prediction Using Machine Learning
=============================================================================
"""

import os
import sys
import pickle
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_DIR = os.path.join(BASE_DIR, '..', 'Dataset')

def load_data(raw_path=None):
    if raw_path is None:
        raw_path = os.path.join(DATASET_DIR, 'orders.csv')
    return pd.read_csv(raw_path)

def clean_data(df):
    """Handle missing values and IQR outliers on total_amount."""
    df_clean = df.copy()
    
    # Missing values
    num_cols = df_clean.select_dtypes(include=[np.number]).columns
    for c in num_cols:
        if df_clean[c].isnull().sum() > 0:
            df_clean[c] = df_clean[c].fillna(df_clean[c].median())
            
    cat_cols = [c for c in df_clean.columns if c not in num_cols]
    for c in cat_cols:
        if df_clean[c].isnull().sum() > 0:
            df_clean[c] = df_clean[c].fillna(df_clean[c].mode()[0])
            
    # Remove duplicate rows
    df_clean = df_clean.drop_duplicates()
    
    # IQR outlier filtering on total_amount
    q1 = df_clean['total_amount'].quantile(0.25)
    q3 = df_clean['total_amount'].quantile(0.75)
    iqr = q3 - q1
    lower = max(0.0, q1 - 1.5 * iqr)
    upper = q3 + 1.5 * iqr
    
    df_clean = df_clean[(df_clean['total_amount'] >= lower) & (df_clean['total_amount'] <= upper)].copy()
    return df_clean

def engineer_features(df):
    """Extract temporal features and formulate classification target."""
    df_feat = df.copy()
    df_feat['order_date'] = pd.to_datetime(df_feat['order_date'])
    
    df_feat['month']       = df_feat['order_date'].dt.month
    df_feat['day']         = df_feat['order_date'].dt.day
    df_feat['day_of_week'] = df_feat['order_date'].dt.day_of_week
    df_feat['hour']        = df_feat['order_date'].dt.hour
    df_feat['is_weekend']  = (df_feat['day_of_week'] >= 5).astype(int)
    df_feat['amount_log']  = np.log1p(df_feat['total_amount'])
    
    # Target
    df_feat['is_returned'] = (df_feat['order_status'].str.lower() == 'returned').astype(int)
    return df_feat

def run_pipeline():
    print("Executing complete Data Preprocessing Pipeline...")
    raw_df = load_data()
    print(f"Loaded raw dataset: {raw_df.shape[0]:,} rows")
    
    clean_df = clean_data(raw_df)
    clean_path = os.path.join(DATASET_DIR, 'orders_clean.csv')
    clean_df.to_csv(clean_path, index=False)
    print(f"Cleaned dataset saved: {clean_path} ({clean_df.shape[0]:,} rows)")
    
    feat_df = engineer_features(clean_df)
    features = ['total_amount', 'amount_log', 'month', 'day', 'day_of_week', 'hour', 'is_weekend']
    target = 'is_returned'
    
    X = feat_df[features]
    y = feat_df[target]
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    
    scaler = StandardScaler()
    X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=features, index=X_train.index)
    X_test_scaled  = pd.DataFrame(scaler.transform(X_test), columns=features, index=X_test.index)
    
    split_path = os.path.join(DATASET_DIR, 'split_data.pkl')
    with open(split_path, 'wb') as f:
        pickle.dump((X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler, features, target), f)
        
    print(f"Train/Test split & scaler saved: {split_path}")
    print("[OK] Preprocessing pipeline finished successfully.")

if __name__ == '__main__':
    run_pipeline()
