"""
=============================================================================
Module: Interactive CLI Prediction Script
Project: E-Commerce Return Prediction Using Machine Learning
=============================================================================
"""

import os
import sys
import joblib
import numpy as np
import pandas as pd

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, '..', 'models', 'best_model.joblib')

def predict_single_order(total_amount, month=6, day=15, day_of_week=2, hour=14):
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Please run train_model.py or practical_10 first.")
        
    pkg = joblib.load(MODEL_PATH)
    model = pkg['model']
    scaler = pkg['scaler']
    features = pkg['features']
    
    amount_log = np.log1p(total_amount)
    is_weekend = 1 if day_of_week >= 5 else 0
    
    input_data = pd.DataFrame([{
        'total_amount': float(total_amount),
        'amount_log': float(amount_log),
        'month': int(month),
        'day': int(day),
        'day_of_week': int(day_of_week),
        'hour': int(hour),
        'is_weekend': int(is_weekend)
    }])[features]
    
    scaled_input = pd.DataFrame(scaler.transform(input_data), columns=features)
    pred = model.predict(scaled_input)[0]
    prob = model.predict_proba(scaled_input)[0, 1] if hasattr(model, "predict_proba") else float(pred)
    
    if prob < 0.35:
        risk = "LOW RISK"
        recommendation = "Standard order dispatch. Low probability of return."
    elif prob < 0.65:
        risk = "MODERATE RISK"
        recommendation = "Normal fulfillment. Standard customer notifications recommended."
    else:
        risk = "HIGH RISK"
        recommendation = "High return probability! Recommend phone confirmation or delivery address re-verification."
        
    return {
        'prediction': int(pred),
        'label': 'RETURNED' if pred == 1 else 'NOT RETURNED',
        'probability': round(prob, 4),
        'probability_pct': round(prob * 100, 2),
        'risk_tier': risk,
        'recommendation': recommendation
    }

if __name__ == '__main__':
    print("=" * 60)
    print("  E-Commerce Return Prediction — Interactive CLI Predictor")
    print("=" * 60)
    try:
        amt = float(input("Enter Order Total Amount (Rs.): ") or 750.0)
        m = int(input("Enter Order Month (1-12) [default 6]: ") or 6)
        d = int(input("Enter Order Day (1-31) [default 15]: ") or 15)
        dow = int(input("Enter Day of Week (0=Mon, 6=Sun) [default 2]: ") or 2)
        h = int(input("Enter Hour of Day (0-23) [default 14]: ") or 14)
    except Exception:
        amt, m, d, dow, h = 750.0, 6, 15, 2, 14
        print(f"Using default sample: Amount=Rs.{amt}, Month={m}, Day={d}, DoW={dow}, Hour={h}")
        
    res = predict_single_order(amt, m, d, dow, h)
    print("\n" + "─" * 45)
    print("PREDICTION RESULT:")
    print("─" * 45)
    print(f"Predicted Status  : {res['label']} ({res['prediction']})")
    print(f"Return Probability: {res['probability_pct']}%")
    print(f"Risk Assessment   : {res['risk_tier']}")
    print(f"Action Advice     : {res['recommendation']}")
    print("─" * 45)
