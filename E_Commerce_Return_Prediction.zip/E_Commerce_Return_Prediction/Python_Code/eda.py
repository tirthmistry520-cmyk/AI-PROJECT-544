"""
=============================================================================
Module: Exploratory Data Analysis (EDA) Module
Project: E-Commerce Return Prediction Using Machine Learning
=============================================================================
"""

import os
import sys
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, '..', 'Dataset', 'orders.csv')
REPORTS_DIR = os.path.join(BASE_DIR, '..', 'Reports')

def generate_all_eda():
    os.makedirs(REPORTS_DIR, exist_ok=True)
    df = pd.read_csv(DATASET_PATH)
    df['order_date'] = pd.to_datetime(df['order_date'])
    df['is_returned'] = (df['order_status'].str.lower() == 'returned').astype(int)
    df['month'] = df['order_date'].dt.month
    df['day'] = df['order_date'].dt.day
    df['day_of_week'] = df['order_date'].dt.day_of_week
    df['hour'] = df['order_date'].dt.hour
    df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)

    day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

    # 1. Histograms
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes[0, 0].hist(df['total_amount'], bins=40, color='#3498db', edgecolor='black')
    axes[0, 0].set_title('Total Amount Distribution')
    axes[0, 1].hist(df['hour'], bins=24, color='#2ecc71', edgecolor='black')
    axes[0, 1].set_title('Hour of Day (0-23)')
    axes[1, 0].hist(df['month'], bins=12, color='#e67e22', edgecolor='black')
    axes[1, 0].set_title('Month Distribution')
    axes[1, 1].hist(df['day_of_week'], bins=7, color='#9b59b6', edgecolor='black')
    axes[1, 1].set_title('Day of Week')
    axes[1, 1].set_xticks(range(7))
    axes[1, 1].set_xticklabels(day_names)
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, 'histogram.png'), dpi=150)
    plt.close()

    # 2. Boxplot
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    axes[0].boxplot(df['total_amount'], patch_artist=True, boxprops=dict(facecolor='#ff7675'))
    axes[0].set_title('Total Amount Outliers')
    palette = {'shipped': '#74b9ff', 'returned': '#ff7675', 'completed': '#55efc4',
               'cancelled': '#ffeaa7', 'processing': '#a29bfe'}
    sns.boxplot(x='order_status', y='total_amount', hue='order_status', data=df, ax=axes[1], palette=palette, legend=False)
    axes[1].set_title('Amount by Order Status')
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, 'boxplot.png'), dpi=150)
    plt.close()

    # 3. Pie Charts
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    df['order_status'].value_counts().plot.pie(ax=axes[0], autopct='%1.1f%%', startangle=140)
    axes[0].set_title('Order Status Breakdown')
    axes[0].set_ylabel('')
    axes[1].pie([len(df) - df['is_returned'].sum(), df['is_returned'].sum()],
                labels=['Not Returned', 'Returned'], autopct='%1.1f%%',
                colors=['#74b9ff', '#ff7675'], startangle=90)
    axes[1].set_title('Target Class Balance')
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, 'pie_chart.png'), dpi=150)
    plt.close()

    # 4. Correlation Matrix
    plt.figure(figsize=(9, 7))
    sns.heatmap(df[['total_amount', 'month', 'day', 'day_of_week', 'hour', 'is_weekend', 'is_returned']].corr(),
                annot=True, fmt='.3f', cmap='coolwarm')
    plt.title('Correlation Matrix')
    plt.tight_layout()
    plt.savefig(os.path.join(REPORTS_DIR, 'correlation_matrix.png'), dpi=150)
    plt.close()

    print("[OK] Standalone EDA visual reports generated in Reports/ folder.")

if __name__ == '__main__':
    generate_all_eda()
