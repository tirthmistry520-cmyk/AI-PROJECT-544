# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 3 — Understanding Data
# ============================================================
#  Unit Covered : Unit-1
# ============================================================

import os
import sys
import pandas as pd
import numpy as np

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'orders.csv')

df = pd.read_csv(DATA_PATH)

print("=" * 65)
print("PRACTICAL 3 : Understanding Data")
print("=" * 65)

print("\n1. DATA TYPES")
print(df.dtypes)

numerical_cols   = df.select_dtypes(include=[np.number]).columns.tolist()
categorical_cols = [c for c in df.columns if c not in numerical_cols]

print(f"\n2. NUMERICAL COLUMNS ({len(numerical_cols)})")
print(f"   {numerical_cols}")

print(f"\n3. CATEGORICAL / STRING COLUMNS ({len(categorical_cols)})")
print(f"   {categorical_cols}")

print("\n4. UNIQUE VALUE COUNTS PER COLUMN")
for col in df.columns:
    print(f"   {col:<16}: {df[col].nunique():>6} unique values")

print("\n5. UNIQUE VALUES IN CATEGORICAL ATTRIBUTES")
print(f"   order_status : {sorted(df['order_status'].unique().tolist())}")

print(f"\n6. MISSING VALUES PER COLUMN")
missing = df.isnull().sum()
print(missing)
print(f"   Total missing cells : {missing.sum()}")

print(f"\n7. DUPLICATE RECORDS")
duplicate_count = df.duplicated().sum()
print(f"   Total duplicate rows: {duplicate_count}")

print("\n8. STATISTICAL SUMMARY (Numerical Features)")
print(df.describe().round(2))

# Temporal range overview
order_dates = pd.to_datetime(df['order_date'])
print("\n9. TEMPORAL COVERAGE")
print(f"   Earliest Order Date : {order_dates.min()}")
print(f"   Latest Order Date   : {order_dates.max()}")
print(f"   Total Date Span     : {(order_dates.max() - order_dates.min()).days} days")

print("\n" + "=" * 65)
print("DATASET INTEGRITY SUMMARY")
print("=" * 65)
print(f"  Total Records   : {df.shape[0]:,}")
print(f"  Total Columns   : {df.shape[1]}")
print(f"  Unique Customers: {df['user_id'].nunique():,}")
print(f"  Missing Values  : {missing.sum()}")
print(f"  Duplicate Rows  : {duplicate_count}")
print(f"  Amount Range    : Rs.{df['total_amount'].min():.2f} to Rs.{df['total_amount'].max():.2f}")
print("=" * 65)
print("[OK] Practical 3 completed successfully.")
