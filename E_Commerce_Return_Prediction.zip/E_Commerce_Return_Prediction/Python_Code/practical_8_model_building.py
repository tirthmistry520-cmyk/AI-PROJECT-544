# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 8 — Build ML Model (Logistic Regression)
# ============================================================
#  Unit Covered : Unit-4
# ============================================================

import os
import sys
import pickle
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SPLIT_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'split_data.pkl')
RESULTS_PATH = os.path.join(SCRIPT_DIR, '..', 'Dataset', 'model_results.pkl')

with open(SPLIT_PATH, 'rb') as f:
    X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler, FEATURES, TARGET = pickle.load(f)

print("=" * 65)
print("PRACTICAL 8 : Model Building - Logistic Regression")
print("=" * 65)
print(f"Algorithm : Logistic Regression (Binary Classification)")
print(f"Target    : is_returned (0 = Not Returned, 1 = Returned)")
print(f"Features  : {len(FEATURES)} inputs ({FEATURES})")
print(f"Train set : {X_train.shape[0]:,} records")
print(f"Test set  : {X_test.shape[0]:,} records")

# ── 1. Train Logistic Regression Model ────────────────────
print("\n[1] Training Logistic Regression Classifier...")
model = LogisticRegression(max_iter=1000, random_state=42, class_weight='balanced')
model.fit(X_train_scaled, y_train)
print("    [OK] Model trained successfully!")

# ── 2. Model Coefficients & Odds Ratios ───────────────────
print(f"\nModel Intercept (Bias): {model.intercept_[0]:.4f}")

coef_df = pd.DataFrame({
    'Feature': FEATURES,
    'Coefficient': model.coef_[0],
    'Odds_Ratio': np.exp(model.coef_[0])
})
coef_df['Abs_Importance'] = coef_df['Coefficient'].abs()
coef_df = coef_df.sort_values(by='Abs_Importance', ascending=False).drop(columns=['Abs_Importance'])

print("\nFeature Coefficients & Odds Ratios (sorted by absolute impact):")
print(coef_df.to_string(index=False))

# ── 3. Predictions on Test Set ────────────────────────────
y_pred = model.predict(X_test_scaled)
y_prob = model.predict_proba(X_test_scaled)[:, 1]

print("\nSample Test Set Predictions (First 10 records):")
sample_df = pd.DataFrame({
    'Actual': y_test.values[:10],
    'Predicted': y_pred[:10],
    'Return_Prob(%)': (y_prob[:10] * 100).round(2),
    'Outcome': ['Correct' if a == p else 'Misclassified' for a, p in zip(y_test.values[:10], y_pred[:10])]
})
print(sample_df.to_string(index=False))

# ── 4. Save Trained Model Results ─────────────────────────
with open(RESULTS_PATH, 'wb') as f:
    pickle.dump((model, y_pred, y_prob, y_test, X_train_scaled, X_test_scaled, FEATURES), f)

print(f"\n[OK] Model results saved -> Dataset/model_results.pkl")
print("=" * 65)
print("[OK] Practical 8 completed successfully.")
