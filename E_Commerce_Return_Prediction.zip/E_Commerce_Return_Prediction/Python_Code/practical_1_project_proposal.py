# ============================================================
#  SYBCA-AI (Sem-III) | 303 Machine Learning
#  Practical 1 — Project Proposal
# ============================================================
#
#  Project Title    : E-Commerce Return Prediction Using Machine Learning
#
#  Problem Statement:
#    E-commerce businesses process thousands of orders daily across
#    diverse categories, price points, and fulfillment stages. Returned
#    merchandise incurs reverse logistics costs, inventory holding
#    losses, and customer dissatisfaction. Predicting whether an order
#    is likely to be returned allows online merchants to take proactive
#    operational actions (e.g., automated address verification, fraud
#    checks, post-order support, or selective free return policies).
#    This project formulates return prediction as a supervised binary
#    classification problem, using Logistic Regression as the baseline
#    algorithm and comparing it against Decision Tree and Random Forest
#    classifiers on a 20,000-record order dataset.
#
#  Dataset Source   : E-Commerce Orders Dataset (orders.csv)
#                     20,000 records | 5 attributes | CSV format
#
#  Objectives:
#    1. Understand, clean, and validate 20,000 order transactions.
#    2. Conduct thorough Exploratory Data Analysis (EDA) on order
#       values, order timing, and return frequencies.
#    3. Perform Feature Engineering: extract temporal features (month,
#       day, weekday, hour, weekend flag) and scale numeric inputs.
#    4. Train and compare supervised classification algorithms:
#       Logistic Regression, Decision Tree, and Random Forest.
#    5. Evaluate performance using Accuracy, Precision, Recall,
#       F1-Score, Confusion Matrix, and ROC-AUC curve.
#    6. Improve robustness through 5-Fold Stratified Cross-Validation.
#    7. Build an interactive Streamlit web dashboard for real-time
#       order return risk scoring and batch processing.
#
#  Expected Output:
#    A production-ready classification model that outputs return
#    probabilities (0 to 1) and risk categorizations, supported by
#    comprehensive evaluation reports and an interactive web interface.
# ============================================================

import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

print("=" * 65)
print("  Project Proposal - E-Commerce Return Prediction System")
print("=" * 65)
print("Title     : E-Commerce Return Prediction Using Machine Learning")
print("Domain    : E-Commerce & Retail Analytics")
print("Dataset   : E-Commerce Orders Dataset (orders.csv)")
print("Records   : 1,000  |  Original Attributes : 5")
print("Target    : is_returned  (Binary Classification: 0 = No, 1 = Yes)")
print("Algorithms: Logistic Regression (Baseline), Decision Tree, Random Forest")
print("Metrics   : Accuracy, Precision, Recall, F1-Score, ROC-AUC")
print("=" * 65)
print("[OK] Practical 1 completed successfully.")
