# 📦 E-Commerce Return Prediction System — Quick Guide & Project Info

> **Course**: SYBCA-AI (Semester-III) | **Subject**: 303 Machine Learning  
> **Dataset**: `orders.csv` (20,000 orders, 8,635 unique users)  
> **Target**: `is_returned` (0 = Kept / Normal Delivery, 1 = Returned)

---

## 🎯 1. Model Accuracy — Kitna % Accurate Hai?

### Technical Numbers (Test Set Par):
| Algorithm | Accuracy (%) | Precision (%) | Recall (%) | F1-Score | ROC-AUC |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Decision Tree (Best Model)** | **60.78%** | 20.81% | 32.89% | 0.2549 | **0.5126** |
| **Random Forest** | **55.04%** | 21.08% | 43.90% | 0.2849 | 0.5043 |
| **Logistic Regression (Baseline)** | **49.72%** | 20.02% | **48.94%** | **0.2842** | 0.5090 |

* **Champion Model**: `models/best_model.joblib` (Decision Tree Classifier)
* **Test Predictions Saved**: `Results/predictions.csv` (3,697 test orders scored)

---

## 🗣️ 2. Non-Technical / Simple Bhasha Me Matlab

### Aasan Shando Me:
> **Har 100 customer orders me se hamara best model lagbhag 61 orders ka sahi faisla leta hai (61% accuracy).**

* Normal coin flip (tukka) **50%** hota hai.
* Hamara model **61%** nikal raha hai, yaani data ke patterns ko samajh kar faisla le raha hai.

---

### ⚠️ The "Lazy Employee" Trap (Viva Ke Liye Bahut Zaroori Point)

Hamare dataset me:
* **~80% orders deliver ho jate hain** (Not Returned).
* Sirf **~20% orders return aate hain**.

Agar koi "aalsi employee" bina dekhe bol de ki *"Koi bhi order wapas nahi aayega"*, to woh technically **80% sahi** hoga — lekin yeh **100% bekar** hai kyunki woh **ek bhi return nahi pakad payega**!

Hamara AI model yeh chalaki nahi karta:
* Humne model me `class_weight='balanced'` lagaya hai.
* Iska main kaam return hone wale khatarnaak orders ko pehle se pakadna hai (lagbhag **49% actual returns** ko pehle hi dhoondh nikalta hai).

---

## 🔍 3. Model Kese Check Karta Hai: Low, Medium, ya High Risk?

AI seedha "Yes" ya "No" nahi bolta. Woh har order ko **0% se 100% ke beech ek Return Probability Score** deta hai.

### 🚥 The 3 Risk Tiers (Score Categories):

| Score (Return Chance) | Risk Level | Matlab Kya Hai? | Company Ko Kya Action Lena Chahiye? |
| :---: | :---: | :--- | :--- |
| **0% se 35%** | 🟢 **Low Risk** | Parcel wapas aane ka chance bohot kam hai. | **Direct Dispatch**: Normal speed se parcel bhej do. |
| **35% se 65%** | 🟡 **Medium Risk** | 50-50 chance hai, thoda dhyan rakhna hai. | **Automated Alerts**: Customer ko WhatsApp / SMS par live tracking bhejo taaki delivery miss na ho. |
| **65% se 100%** | 🔴 **High Risk** | Bohot high chance hai ki parcel return aayega. | **Pre-Dispatch Verification**: Bhejne se pehle customer ko phone call karke address, pin code aur order confirm karo! |

---

### 🕵️ AI Kaun-Kaun Se "Clues" (Features) Dekhta Hai?

1. **Order Amount (रुपये / कीमत):**
   * Chota order hai (jaise ₹200) ya bohot mehanga item (jaise ₹2,000 - ₹5,000+)?
   * Online stores me mehnge items par customer impulse buy karte hain aur return rate badh jata hai.
2. **Order Timing / Hour (दिन का समय):**
   * Order din me 2 baje office hours me hua, ya der raat 3:00 AM par neend me hua?
3. **Weekday vs Weekend (दिन):**
   * Somwar-Shukrawar ka order hai ya Shanivar-Ravivar ka? Weekends par log aamtaur par zyada browsing aur cancel/returns karte hain.
4. **Month & Day (महीना और तारीख):**
   * Month-end (salary khatam) ya month-start ke spending trends.

---

### 📦 Asli Zindagi Ke Do Examples (Real Comparison)

#### 🟢 Example A (Safe Order):
* **Amount**: ₹250
* **Timing**: Mangalwar (Tuesday) dopahar 12:30 PM
* **AI Score**: **18% Return Probability**
* **Result**: **🟢 Low Risk** → Warehouse se seedha pack karke bhej diya gaya. Extra checking ki zaroorat nahi.

#### 🔴 Example B (Risky Order):
* **Amount**: ₹1,850
* **Timing**: Shanivar (Saturday) raat 2:45 AM
* **AI Score**: **74% Return Probability**
* **Result**: **🔴 High Risk** → Dashboard par red alert dikha. Store manager ne dispatch karne se pehle customer ko call karke confirm kiya. Isse double shipping ka nuksan hone se bach gaya!

---

## 💼 4. Business Value (Dukaan / Company Ko Kya Fayda?)

| Pehle (Bina AI ke) | Ab (Hamare AI System ke Sath) |
| :--- | :--- |
| Saare 20,000 parcels bina soche samjhe ship kar diye jaate the. | System pehle hi bata deta hai kaunse parcel me return ka khatra zyada hai. |
| Har returned order par aane-jaane ka double courier charge lagta tha. | High-risk parcels ko verify karke courier charges bachaye ja sakte hain. |
| Store managers andhere me teer chalate the. | Live **Streamlit Dashboard** par risk meter aur real-time score milta hai. |

---

## 🚀 5. Quick Commands (Project Run Karne Ke Liye)

### Practicals Run Karne Ke Liye:
```powershell
cd d:\Python\E_Commerce_Return_Prediction\Python_Code
py practical_1_project_proposal.py
py practical_8_model_building.py
py practical_10_improve_model.py
py practical_11_results_conclusion.py
```

### Interactive Streamlit App Chalane Ke Liye:
```powershell
cd d:\Python\E_Commerce_Return_Prediction
py -m streamlit run app.py
```

---

## 🎓 6. One-Line Summary (Viva / Panel Ke Liye)
> *"Our project uses Machine Learning classification (Decision Tree & Logistic Regression) to calculate an order's return risk score (0-100%) based on amount and timing, allowing e-commerce merchants to catch high-risk returns before shipping and save logistics costs."*
