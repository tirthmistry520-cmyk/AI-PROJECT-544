# 📦 E-Commerce Return Prediction Using Machine Learning

![Python](https://img.shields.io/badge/Python-3.13-blue.svg)
![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.6%2B-orange.svg)
![Streamlit](https://img.shields.io/badge/Streamlit-1.30%2B-red.svg)
![Course](https://img.shields.io/badge/Course-SYBCA--AI%20(Sem--III)-green.svg)
![Subject](https://img.shields.io/badge/Subject-303%20Machine%20Learning-purple.svg)

A complete, production-grade Machine Learning classification project developed for **SYBCA-AI (Semester-III) — 303 Machine Learning Mini Project**. The system predicts customer order return likelihood from 20,000 transaction records using **Logistic Regression** (baseline linear classifier) and compares it against **Decision Tree** and **Random Forest** ensemble classifiers.

---

## 📌 1. Project Overview & Problem Statement

### Problem Statement
In e-commerce, returned merchandise represents a severe operational hurdle:
- Incurring double shipping and reverse logistics expenses.
- Tying up inventory and decreasing product turnover.
- Leading to customer churn if return friction occurs.

This project builds an automated Machine Learning pipeline to score the return probability of customer orders before final delivery, enabling online retailers to implement proactive measures (e.g., verifying shipping addresses, phone confirmations on high-risk items, or optimizing return logistics).

### Project Metadata
- **Domain**: E-Commerce & Retail Analytics
- **Machine Learning Type**: Supervised Learning — Binary Classification
- **Primary Algorithm**: Logistic Regression (with Decision Tree & Random Forest comparison)
- **Dataset Size**: 20,000 orders across 8,635 unique users
- **Target Variable**: `is_returned` (0 = Kept / Other, 1 = Returned)

---

## 📊 2. Dataset Analysis

The dataset consists of 20,000 transaction records with the following original attributes:

| Column Name | Data Type | Description | Role in ML Pipeline |
| :--- | :--- | :--- | :--- |
| `order_id` | Alphanumeric | Unique order transaction ID | Identifier (Dropped to avoid overfitting) |
| `user_id` | Alphanumeric | Unique customer account ID | Identifier (Dropped to avoid overfitting) |
| `order_date` | Datetime (ISO) | Timestamp of purchase | Feature extraction (month, day, weekday, hour) |
| `order_status` | String | Fulfillment status | Target derivation (`is_returned`) & then dropped to prevent leakage |
| `total_amount` | Float | Invoice monetary value (₹ / USD) | Numerical feature & IQR outlier inspection |

### Original Order Status Breakdown
| Status | Record Count | Percentage |
| :--- | :---: | :---: |
| **Shipped** | 4,113 | 20.57% |
| **Returned** | 4,066 | 20.33% |
| **Completed** | 4,021 | 20.10% |
| **Cancelled** | 3,920 | 19.60% |
| **Processing** | 3,880 | 19.40% |
| **Total** | **20,000** | **100.0%** |

---

## 🔄 3. Machine Learning Architecture & Workflow

```mermaid
flowchart TD
    A[orders.csv (20,000 records)] --> B[Data Understanding & Missing Value Checks]
    B --> C[IQR Outlier Handling on total_amount]
    C --> D[Exploratory Data Analysis - Matplotlib & Seaborn]
    D --> E[Feature Engineering: month, day, weekday, hour, weekend flag, log amount]
    E --> F[Train-Test Split: 80% Train / 20% Test with Stratification]
    F --> G[StandardScaler Normalization]
    G --> H[Model Training & Cross-Validation]
    H --> H1[Logistic Regression - Baseline]
    H --> H2[Decision Tree Classifier]
    H --> H3[Random Forest Classifier]
    H1 --> I[Comprehensive Model Evaluation]
    H2 --> I
    H3 --> I
    I --> J[Select Best Model Artifact -> best_model.joblib]
    J --> K[Interactive Streamlit Web Dashboard & CLI Predictor]
    K --> L[Real-Time Risk Scoring & Action Recommendation]
```

---

## 📁 4. Project Folder Structure

```
E_Commerce_Return_Prediction/
│
├── Dataset/
│   ├── orders.csv                 ← Original 20,000-record dataset
│   ├── orders_clean.csv           ← Generated clean dataset (post Practical 5)
│   ├── split_data.pkl             ← Stratified 80:20 train/test data (Practical 7)
│   └── model_results.pkl          ← Model weights and test predictions (Practical 8)
│
├── Python_Code/
│   ├── practical_1_project_proposal.py          ← Practical 1: Proposal & Objectives
│   ├── practical_2_dataset_collection.py        ← Practical 2: Dataset Loading & Overview
│   ├── practical_3_understanding_data.py        ← Practical 3: Nulls, Duplicates & Types
│   ├── practical_4_eda.py                       ← Practical 4: Five Visual EDA Reports
│   ├── practical_5_handle_missing_outliers.py   ← Practical 5: Missing Imputation & IQR
│   ├── practical_6_automated_eda.py             ← Practical 6: Sweetviz / HTML Profiling
│   ├── practical_7_feature_selection.py         ← Practical 7: Feature Engineering & Split
│   ├── practical_8_model_building.py            ← Practical 8: Logistic Regression Model
│   ├── practical_9_model_evaluation.py          ← Practical 9: Confusion Matrix & ROC Curve
│   ├── practical_10_improve_model.py            ← Practical 10: 5-Fold CV & Multi-Algorithm
│   ├── practical_11_results_conclusion.py       ← Practical 11: Final Conclusions & Summary
│   ├── data_preprocessing.py                    ← Modular data pipeline
│   ├── eda.py                                   ← Modular visualizer script
│   ├── train_model.py                           ← Modular trainer script
│   ├── evaluate_model.py                        ← Modular evaluator script
│   └── predict.py                               ← Interactive CLI prediction tool
│
├── models/
│   └── best_model.joblib          ← Champion model artifact with scaler & feature metadata
│
├── Reports/
│   ├── EDA_Report.html            ← Automated interactive profiling report
│   ├── histogram.png              ← Feature distribution histograms
│   ├── boxplot.png                ← Outlier inspection box plots
│   ├── pie_chart.png              ← Status and target class distributions
│   ├── bar_chart.png              ← Return rates by day, hour & monthly trends
│   ├── correlation_matrix.png     ← Pearson correlation heatmap
│   ├── before_after_outliers.png  ← IQR outlier comparison
│   ├── feature_correlation.png    ← Correlation of engineered features with target
│   ├── confusion_matrix.png       ← Test set confusion matrix
│   ├── roc_curve.png              ← ROC curve with AUC score
│   ├── model_comparison.png       ← Algorithm comparison bar chart
│   └── feature_importance.png     ← Feature weights / coefficient analysis
│
├── Results/
│   ├── model_comparison.csv       ← Quantitative leaderboard of all algorithms
│   ├── confusion_matrix.png       ← Exported confusion matrix
│   └── predictions.csv            ← Test set predictions with risk tiers
│
├── app.py                         ← Streamlit Web Application
├── requirements.txt               ← Python dependencies
├── README.md                      ← Detailed project documentation
└── README.txt                     ← Reference format run guide
```

---

## 🚀 5. How to Run the Project

### Step 1: Install Dependencies
Open your terminal (PowerShell or Command Prompt) and install the requirements:
```bash
py -m pip install -r requirements.txt
```

### Step 2: Run Practicals Sequentially
Navigate to `Python_Code/` and execute each practical:
```bash
cd Python_Code

py practical_1_project_proposal.py
py practical_2_dataset_collection.py
py practical_3_understanding_data.py
py practical_4_eda.py
py practical_5_handle_missing_outliers.py
py practical_6_automated_eda.py
py practical_7_feature_selection.py
py practical_8_model_building.py
py practical_9_model_evaluation.py
py practical_10_improve_model.py
py practical_11_results_conclusion.py
```

### Step 3: Launch Interactive Web Application (Streamlit)
```bash
cd ..
py -m streamlit run app.py
```
Open your browser to `http://localhost:8501` to use the interactive dashboard.

---

## 📈 6. Practical Modules & Academic Syllabus Alignment

| Practical | Title | Unit | Primary Output |
| :--- | :--- | :---: | :--- |
| **Practical 1** | Project Proposal | Unit-1 | Project proposal, scope, and objectives |
| **Practical 2** | Dataset Collection & Description | Unit-1 | Shape, sample records, column dictionary |
| **Practical 3** | Understanding Data | Unit-1 | Data types, missing values, duplicates, summary stats |
| **Practical 4** | Exploratory Data Analysis | Unit-1 & 2 | Histograms, boxplots, pie charts, correlation matrix |
| **Practical 5** | Handle Missing & Outliers | Unit-2 | Imputation, IQR bounds filtering, `orders_clean.csv` |
| **Practical 6** | Automated EDA | Unit-2 | Interactive `Reports/EDA_Report.html` profiling |
| **Practical 7** | Feature Selection & Split | Unit-3 | Datetime extraction, correlation chart, `split_data.pkl` |
| **Practical 8** | Model Building | Unit-4 | Logistic Regression training, odds ratios, `model_results.pkl` |
| **Practical 9** | Model Evaluation | Unit-3 & 4 | Accuracy, Precision, Recall, F1, `confusion_matrix.png`, `roc_curve.png` |
| **Practical 10** | Improve Model & Comparison | Unit-4 | 5-Fold Stratified CV, comparison chart, `best_model.joblib` |
| **Practical 11** | Results & Conclusion | Unit-3 & 4 | `predictions.csv`, business recommendations & final report |

---

## 💻 7. Interactive Streamlit Features
- **🎯 Single Order Risk Predictor**: Enter order amount, date, and hour to get real-time return probability, risk gauge, and merchant recommendation.
- **📂 Batch Predictions**: Process entire test batches or upload custom CSV orders with downloadable scored CSV.
- **📊 Model Performance Leaderboard**: Interactive comparison of Accuracy, Precision, Recall, F1, and ROC-AUC.
- **📈 EDA Analytics**: Interactive charts exploring order distributions and return rates.
- **📚 Syllabus Mapping**: Complete academic information aligned with course guidelines.

---
*Created for SYBCA-AI (Sem-III) 303 Machine Learning Mini Project.*
