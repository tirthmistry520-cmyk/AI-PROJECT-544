"""
=============================================================================
  E-Commerce Return Prediction System — Interactive Streamlit Dashboard
  SYBCA-AI (Sem-III) | 303 Machine Learning Project
=============================================================================
"""

import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import datetime
import plotly.express as px
import plotly.graph_objects as go
import warnings
warnings.filterwarnings('ignore')

# ── Page Configuration ─────────────────────────────────────
st.set_page_config(
    page_title="E-Commerce Return Prediction",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── Custom CSS for High-End Aesthetics ─────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Outfit', sans-serif;
    }
    
    .main-header {
        background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #311042 100%);
        padding: 24px 30px;
        border-radius: 16px;
        color: white;
        margin-bottom: 25px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
    }
    
    .badge-pill {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin-right: 8px;
    }
    .badge-blue { background: rgba(56, 189, 248, 0.2); color: #38bdf8; border: 1px solid #38bdf8; }
    .badge-purple { background: rgba(168, 85, 247, 0.2); color: #c084fc; border: 1px solid #a855f7; }
    
    .metric-card {
        background: rgba(30, 41, 59, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .metric-card:hover {
        transform: translateY(-2px);
        border-color: rgba(56, 189, 248, 0.4);
    }
    
    .risk-high {
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.15) 0%, rgba(185, 28, 28, 0.25) 100%);
        border: 1px solid #ef4444;
        border-radius: 12px;
        padding: 16px;
        color: #fca5a5;
    }
    .risk-mod {
        background: linear-gradient(135deg, rgba(245, 158, 11, 0.15) 0%, rgba(180, 83, 9, 0.25) 100%);
        border: 1px solid #f59e0b;
        border-radius: 12px;
        padding: 16px;
        color: #fcd34d;
    }
    .risk-low {
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(4, 120, 87, 0.25) 100%);
        border: 1px solid #10b981;
        border-radius: 12px;
        padding: 16px;
        color: #6ee7b7;
    }
</style>
""", unsafe_allow_html=True)

# ── Paths ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, 'models', 'best_model.joblib')
DATA_PATH = os.path.join(BASE_DIR, 'Dataset', 'orders_clean.csv')
RAW_DATA_PATH = os.path.join(BASE_DIR, 'Dataset', 'orders.csv')
REPORTS_DIR = os.path.join(BASE_DIR, 'Reports')
RESULTS_DIR = os.path.join(BASE_DIR, 'Results')

# ── Header ─────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
            <span class="badge-pill badge-blue">SYBCA-AI (Sem-III)</span>
            <span class="badge-pill badge-purple">303 Machine Learning</span>
            <h1 style="margin: 8px 0 4px 0; font-size: 28px; font-weight: 700;">📦 E-Commerce Return Prediction System</h1>
            <p style="margin: 0; color: #94a3b8; font-size: 15px;">
                Autonomous risk evaluation engine powered by Machine Learning classification algorithms.
            </p>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

# ── Helper to Load Model ───────────────────────────────────
@st.cache_resource
def load_trained_model():
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    return None

@st.cache_data
def load_datasets():
    clean_df = pd.read_csv(DATA_PATH) if os.path.exists(DATA_PATH) else None
    raw_df = pd.read_csv(RAW_DATA_PATH) if os.path.exists(RAW_DATA_PATH) else None
    return clean_df, raw_df

model_artifact = load_trained_model()
clean_df, raw_df = load_datasets()

# ── Tabs ───────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "🎯 Single Order Predictor",
    "📂 Batch Predictions",
    "📊 Model Performance",
    "📈 Dataset Analytics & EDA",
    "📚 Project & Syllabus Info"
])

# ============================================================
# TAB 1: Single Order Predictor
# ============================================================
with tab1:
    st.subheader("Estimate Return Risk for Individual Order")
    st.caption("Provide transaction parameters to calculate real-time return probability.")
    
    col1, col2 = st.columns([1, 1], gap="large")
    
    with col1:
        st.markdown("### 📝 Order Input Parameters")
        
        total_amount = st.number_input(
            "Total Order Amount (₹ / USD)",
            min_value=1.0,
            max_value=10000.0,
            value=850.0,
            step=25.0,
            help="Total invoice price of customer purchase."
        )
        
        order_date_input = st.date_input(
            "Order Date",
            value=datetime.date.today(),
            help="Calendar date when customer placed order."
        )
        
        order_time_input = st.time_input(
            "Order Time",
            value=datetime.time(14, 30),
            help="Time of day when order transaction occurred."
        )
        
        # Extracted values
        month = order_date_input.month
        day = order_date_input.day
        day_of_week = order_date_input.weekday()
        hour = order_time_input.hour
        is_weekend = 1 if day_of_week >= 5 else 0
        amount_log = np.log1p(total_amount)
        
        day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        
        st.info(f"📅 **Derived Context**: {day_names[day_of_week]} | Month: {month} | Hour: {hour:02d}:00 | Weekend: {'Yes' if is_weekend else 'No'}")
        
        predict_btn = st.button("🚀 Calculate Return Likelihood", type="primary", width="stretch")

    with col2:
        st.markdown("### 🔍 Risk Assessment Result")
        
        if model_artifact is None:
            st.warning("⚠️ Model artifact not found. Run practical_10_improve_model.py to generate models/best_model.joblib.")
        else:
            model = model_artifact['model']
            scaler = model_artifact['scaler']
            features = model_artifact['features']
            model_name = model_artifact['model_name']
            
            # Prepare input
            row_dict = {
                'total_amount': float(total_amount),
                'amount_log': float(amount_log),
                'month': int(month),
                'day': int(day),
                'day_of_week': int(day_of_week),
                'hour': int(hour),
                'is_weekend': int(is_weekend)
            }
            input_df = pd.DataFrame([row_dict])[features]
            scaled_input = pd.DataFrame(scaler.transform(input_df), columns=features)
            
            # Predict
            pred = model.predict(scaled_input)[0]
            prob = model.predict_proba(scaled_input)[0, 1] if hasattr(model, "predict_proba") else float(pred)
            prob_pct = round(prob * 100, 1)
            
            # Gauge chart
            fig = go.Figure(go.Indicator(
                mode="gauge+number",
                value=prob_pct,
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "Return Probability (%)", 'font': {'size': 18, 'color': '#f8fafc'}},
                number={'suffix': "%", 'font': {'size': 36, 'color': '#38bdf8'}},
                gauge={
                    'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#94a3b8"},
                    'bar': {'color': "#38bdf8"},
                    'bgcolor': "rgba(15, 23, 42, 0.6)",
                    'borderwidth': 2,
                    'bordercolor': "#334155",
                    'steps': [
                        {'range': [0, 35], 'color': "rgba(16, 185, 129, 0.3)"},
                        {'range': [35, 65], 'color': "rgba(245, 158, 11, 0.3)"},
                        {'range': [65, 100], 'color': "rgba(239, 68, 68, 0.3)"}
                    ],
                    'threshold': {
                        'line': {'color': "#ef4444", 'width': 3},
                        'thickness': 0.75,
                        'value': prob_pct
                    }
                }
            ))
            fig.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font={'color': "#f8fafc"},
                height=260,
                margin=dict(l=20, r=20, t=40, b=20)
            )
            st.plotly_chart(fig, width="stretch")
            
            # Risk card
            if prob < 0.35:
                st.markdown(f"""
                <div class="risk-low">
                    <h3 style="margin:0 0 5px 0;">🟢 LOW RETURN RISK ({prob_pct}%)</h3>
                    <p style="margin:0;"><strong>Classification:</strong> KEPT / NOT RETURNED</p>
                    <p style="margin:4px 0 0 0; font-size:14px;"><strong>Recommended Action:</strong> Standard fulfillment. Standard shipping speed recommended.</p>
                </div>
                """, unsafe_allow_html=True)
            elif prob < 0.65:
                st.markdown(f"""
                <div class="risk-mod">
                    <h3 style="margin:0 0 5px 0;">🟡 MODERATE RETURN RISK ({prob_pct}%)</h3>
                    <p style="margin:0;"><strong>Classification:</strong> WATCHLIST / MODERATE PROBABILITY</p>
                    <p style="margin:4px 0 0 0; font-size:14px;"><strong>Recommended Action:</strong> Standard dispatch with automated SMS confirmation and tracking updates.</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="risk-high">
                    <h3 style="margin:0 0 5px 0;">🔴 HIGH RETURN RISK ({prob_pct}%)</h3>
                    <p style="margin:0;"><strong>Classification:</strong> HIGH RETURN LIKELIHOOD</p>
                    <p style="margin:4px 0 0 0; font-size:14px;"><strong>Recommended Action:</strong> Proactive phone verification, address check, or selective free return terms.</p>
                </div>
                """, unsafe_allow_html=True)
                
            st.caption(f"Evaluated via **{model_name}** | Preprocessed with StandardScaler")

# ============================================================
# TAB 2: Batch Predictions
# ============================================================
with tab2:
    st.subheader("Batch Order Return Evaluation")
    st.caption("Upload order CSV or process historical test sample orders to score thousands of orders at once.")
    
    uploaded_file = st.file_uploader("Upload CSV file (must include total_amount, order_date)", type=['csv'])
    
    if uploaded_file is not None:
        batch_df = pd.read_csv(uploaded_file)
        st.success(f"Uploaded batch containing {len(batch_df):,} orders.")
    else:
        st.info("💡 Demonstrating with a sample batch of 100 test orders from dataset.")
        if clean_df is not None:
            batch_df = clean_df.sample(n=min(100, len(clean_df)), random_state=42).copy()
        else:
            batch_df = None
            
    if batch_df is not None and model_artifact is not None:
        model = model_artifact['model']
        scaler = model_artifact['scaler']
        features = model_artifact['features']
        
        # Preprocess batch
        b_df = batch_df.copy()
        b_df['order_date'] = pd.to_datetime(b_df['order_date'])
        b_df['month'] = b_df['order_date'].dt.month
        b_df['day'] = b_df['order_date'].dt.day
        b_df['day_of_week'] = b_df['order_date'].dt.day_of_week
        b_df['hour'] = b_df['order_date'].dt.hour
        b_df['is_weekend'] = (b_df['day_of_week'] >= 5).astype(int)
        b_df['amount_log'] = np.log1p(b_df['total_amount'])
        
        X_batch = b_df[features]
        X_batch_scaled = pd.DataFrame(scaler.transform(X_batch), columns=features)
        
        preds = model.predict(X_batch_scaled)
        probs = model.predict_proba(X_batch_scaled)[:, 1] if hasattr(model, "predict_proba") else preds.astype(float)
        
        b_df['Predicted_Return'] = preds
        b_df['Return_Probability'] = (probs * 100).round(2)
        b_df['Risk_Level'] = pd.cut(probs, bins=[-0.01, 0.35, 0.65, 1.0], labels=['Low', 'Moderate', 'High'])
        
        # Summary metrics
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Batch Orders", f"{len(b_df):,}")
        m2.metric("Predicted Returns", f"{preds.sum():,} ({preds.mean()*100:.1f}%)")
        m3.metric("Average Return Risk", f"{probs.mean()*100:.1f}%")
        m4.metric("High-Risk Order Value", f"₹{b_df[b_df['Risk_Level']=='High']['total_amount'].sum():,.2f}")
        
        # Display data
        st.dataframe(
            b_df[['order_id', 'user_id', 'total_amount', 'order_date', 'Predicted_Return', 'Return_Probability', 'Risk_Level']],
            width="stretch",
            height=320
        )
        
        csv_download = b_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            "📥 Download Batch Predictions as CSV",
            data=csv_download,
            file_name="order_return_predictions.csv",
            mime="text/csv"
        )

# ============================================================
# TAB 3: Model Performance
# ============================================================
with tab3:
    st.subheader("Model Comparison & Evaluation Benchmarks")
    st.caption("Quantitative validation metrics from Practical 9 & Practical 10 across candidate algorithms.")
    
    comp_file = os.path.join(RESULTS_DIR, 'model_comparison.csv')
    if os.path.exists(comp_file):
        comp_df = pd.read_csv(comp_file)
        
        col_t1, col_t2 = st.columns([3, 2])
        with col_t1:
            st.markdown("#### 🏆 Algorithm Leaderboard")
            st.dataframe(comp_df.style.highlight_max(subset=['Accuracy', 'ROC_AUC', 'F1_Score'], color='#1e3a8a'), width="stretch")
            
        with col_t2:
            st.markdown("#### 🎯 Evaluation Metrics Comparison")
            fig = px.bar(
                comp_df, x='Model', y=['Accuracy', 'ROC_AUC', 'F1_Score', 'Precision', 'Recall'],
                barmode='group',
                title="Model Performance Comparison",
                color_discrete_sequence=['#38bdf8', '#a855f7', '#ec4899', '#f59e0b', '#10b981']
            )
            fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font_color="#f8fafc", height=320)
            st.plotly_chart(fig, width="stretch")
            
    # Visual evaluation artifacts
    st.markdown("---")
    st.markdown("#### 🖼️ Model Diagnostics & Evaluation Charts")
    
    rep1, rep2 = st.columns(2)
    with rep1:
        cm_path = os.path.join(REPORTS_DIR, 'confusion_matrix.png')
        if os.path.exists(cm_path):
            st.image(cm_path, caption="Confusion Matrix – Test Set Breakdown", width="stretch")
    with rep2:
        roc_path = os.path.join(REPORTS_DIR, 'roc_curve.png')
        if os.path.exists(roc_path):
            st.image(roc_path, caption="ROC Curve – Discrimination Capacity", width="stretch")
            
    feat_path = os.path.join(REPORTS_DIR, 'feature_importance.png')
    if os.path.exists(feat_path):
        st.image(feat_path, caption="Feature Importance & Weights", width="stretch")

# ============================================================
# TAB 4: Dataset Analytics & EDA
# ============================================================
with tab4:
    st.subheader("Exploratory Data Analysis & Analytics Explorer")
    st.caption("Visual findings from 20,000 transactions across amounts, timestamps, and order statuses.")
    
    if raw_df is not None:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Original Transactions", f"{len(raw_df):,}")
        c2.metric("Clean Records", f"{len(clean_df):,}" if clean_df is not None else "N/A")
        c3.metric("Unique Customers", f"{raw_df['user_id'].nunique():,}")
        c4.metric("Avg Order Amount", f"₹{raw_df['total_amount'].mean():.2f}")
        
        st.markdown("---")
        
        # Interactive status chart
        col_e1, col_e2 = st.columns(2)
        with col_e1:
            st.markdown("##### 📦 Fulfillment Status Proportions")
            status_df = raw_df['order_status'].value_counts().reset_index()
            status_df.columns = ['Status', 'Count']
            fig_pie = px.pie(
                status_df, values='Count', names='Status',
                hole=0.4,
                color_discrete_sequence=['#38bdf8', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6']
            )
            fig_pie.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="#f8fafc", height=320)
            st.plotly_chart(fig_pie, width="stretch")
            
        with col_e2:
            st.markdown("##### 💰 Order Amount Spread by Status")
            fig_box = px.box(
                raw_df, x='order_status', y='total_amount',
                color='order_status',
                color_discrete_sequence=['#38bdf8', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6']
            )
            fig_box.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font_color="#f8fafc", height=320)
            st.plotly_chart(fig_box, width="stretch")
            
        # Saved EDA Reports
        st.markdown("---")
        st.markdown("##### 📁 Static Analytical Visualizations Generated in Reports/")
        e1, e2 = st.columns(2)
        with e1:
            h_path = os.path.join(REPORTS_DIR, 'histogram.png')
            if os.path.exists(h_path):
                st.image(h_path, caption="Feature Histograms (Reports/histogram.png)", width="stretch")
        with e2:
            b_path = os.path.join(REPORTS_DIR, 'bar_chart.png')
            if os.path.exists(b_path):
                st.image(b_path, caption="Order Trends & Return Rates (Reports/bar_chart.png)", width="stretch")

# ============================================================
# TAB 5: Project & Syllabus Info
# ============================================================
with tab5:
    st.subheader("Academic Project Specifications & Syllabus Mapping")
    
    st.markdown("""
    ### 🎓 Course & University Context
    - **Class**: SYBCA-AI (Semester-III)
    - **Subject**: 303 Machine Learning
    - **Project Title**: E-Commerce Return Prediction Using Machine Learning
    - **Methodology**: Supervised Machine Learning — Binary Classification
    
    ---
    
    ### 📋 Practical Execution Roadmap
    | Practical | Description | Syllabus Unit | Artifact Generated |
    | :--- | :--- | :--- | :--- |
    | **Practical 1** | Project Proposal & Problem Statement | Unit-1 | Project proposal overview |
    | **Practical 2** | Dataset Collection & Attribute Definition | Unit-1 | Dataset documentation |
    | **Practical 3** | Understanding Data, Nulls & Duplicates | Unit-1 | Summary statistics |
    | **Practical 4** | Exploratory Data Analysis (EDA) Charts | Unit-1 & 2 | `Reports/histogram.png`, `pie_chart.png`, `bar_chart.png` |
    | **Practical 5** | Missing Values & IQR Outlier Filtering | Unit-2 | `Dataset/orders_clean.csv`, `Reports/before_after_outliers.png` |
    | **Practical 6** | Automated EDA Profiling | Unit-2 | `Reports/EDA_Report.html` |
    | **Practical 7** | Feature Engineering & 80:20 Stratified Split | Unit-3 | `Dataset/split_data.pkl`, `feature_correlation.png` |
    | **Practical 8** | Model Building (Logistic Regression) | Unit-4 | `Dataset/model_results.pkl` |
    | **Practical 9** | Model Evaluation (Confusion Matrix & ROC-AUC) | Unit-3 & 4 | `Reports/confusion_matrix.png`, `roc_curve.png` |
    | **Practical 10** | 5-Fold Cross Validation & Algorithm Comparison | Unit-4 | `models/best_model.joblib`, `Results/model_comparison.csv` |
    | **Practical 11** | Results, Test Predictions & Final Conclusion | Unit-3 & 4 | `Results/predictions.csv`, Comprehensive Report |
    
    ---
    
    ### ⚙️ How to Run
    ```bash
    # 1. Navigate to Python_Code directory
    cd Python_Code
    
    # 2. Run all practicals in sequence
    python practical_1_project_proposal.py
    python practical_2_dataset_collection.py
    python practical_3_understanding_data.py
    python practical_4_eda.py
    python practical_5_handle_missing_outliers.py
    python practical_6_automated_eda.py
    python practical_7_feature_selection.py
    python practical_8_model_building.py
    python practical_9_model_evaluation.py
    python practical_10_improve_model.py
    python practical_11_results_conclusion.py
    
    # 3. Launch Streamlit Web Application
    cd ..
    streamlit run app.py
    ```
    """)

# ── Footer ─────────────────────────────────────────────────
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #64748b; font-size: 13px; padding-bottom: 20px;">
    E-Commerce Return Prediction System • SYBCA-AI Sem-III Mini Project • Python 3.13 & Scikit-Learn
</div>
""", unsafe_allow_html=True)
