@echo off
title E-Commerce Return Prediction System - SYBCA-AI (Sem-III)
cd /d "%~dp0"

:: Detect Python executable (prefer 'py', fallback to 'python')
set PYTHON_CMD=py
py -V >nul 2>&1
if errorlevel 1 (
    set PYTHON_CMD=python
)

:MENU
cls
color 0B
echo ============================================================
echo   SYBCA-AI (Sem-III) ^| 303 Machine Learning
echo   Mini Project: E-Commerce Return Prediction System
echo ============================================================
echo.
echo PROJECT PRACTICALS (SYLLABUS ORDER):
echo ------------------------------------------------------------
echo   [1]  Practical 1  : Project Proposal ^& Scope
echo   [2]  Practical 2  : Dataset Collection ^& Description
echo   [3]  Practical 3  : Understanding Data (Types, Nulls, Dups)
echo   [4]  Practical 4  : Exploratory Data Analysis (EDA Charts)
echo   [5]  Practical 5  : Handle Missing Values ^& Outliers (IQR)
echo   [6]  Practical 6  : Automated EDA Profiling (Sweetviz HTML)
echo   [7]  Practical 7  : Feature Selection ^& 80:20 Data Split
echo   [8]  Practical 8  : Model Building (Logistic Regression)
echo   [9]  Practical 9  : Model Evaluation (Confusion Matrix ^& ROC)
echo   [10] Practical 10 : Improve Model (5-Fold CV ^& Multi-Model)
echo   [11] Practical 11 : Results ^& Conclusion (Final Predictions)
echo.
echo APPLICATIONS ^& BATCH RUN:
echo ------------------------------------------------------------
echo   [A]  Run ALL Practicals (1 to 11 in Sequence)
echo   [W]  Launch Web App Dashboard (Interactive Streamlit GUI)
echo   [C]  Interactive CLI Predictor (Single Order Tool)
echo   [I]  Install / Verify Requirements (requirements.txt)
echo   [E]  Exit
echo ============================================================
echo.

set choice=
set /p choice="Enter your choice [1-11, A, W, C, I, E]: "
if defined choice set choice=%choice: =%

if /i "%choice%"=="1" goto P1
if /i "%choice%"=="2" goto P2
if /i "%choice%"=="3" goto P3
if /i "%choice%"=="4" goto P4
if /i "%choice%"=="5" goto P5
if /i "%choice%"=="6" goto P6
if /i "%choice%"=="7" goto P7
if /i "%choice%"=="8" goto P8
if /i "%choice%"=="9" goto P9
if /i "%choice%"=="10" goto P10
if /i "%choice%"=="11" goto P11
if /i "%choice%"=="A" goto RUN_ALL
if /i "%choice%"=="W" goto RUN_WEB
if /i "%choice%"=="C" goto RUN_CLI
if /i "%choice%"=="I" goto RUN_INSTALL
if /i "%choice%"=="E" goto EXIT_APP

echo.
echo [!] Invalid choice! Please select an option from the menu.
echo Press any key to try again...
pause >nul
goto MENU

:P1
cls
echo Running Practical 1: Project Proposal...
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_1_project_proposal.py
goto DONE

:P2
cls
echo Running Practical 2: Dataset Collection...
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_2_dataset_collection.py
goto DONE

:P3
cls
echo Running Practical 3: Understanding Data...
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_3_understanding_data.py
goto DONE

:P4
cls
echo Running Practical 4: Exploratory Data Analysis...
echo (Generates charts in Reports/ folder)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_4_eda.py
goto DONE

:P5
cls
echo Running Practical 5: Handle Missing Values ^& Outliers...
echo (Generates orders_clean.csv in Dataset/ folder)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_5_handle_missing_outliers.py
goto DONE

:P6
cls
echo Running Practical 6: Automated EDA Profiling...
echo (Generates Reports/EDA_Report.html)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_6_automated_eda.py
goto DONE

:P7
cls
echo Running Practical 7: Feature Selection ^& Split...
echo (Generates split_data.pkl in Dataset/ folder)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_7_feature_selection.py
goto DONE

:P8
cls
echo Running Practical 8: Model Building (Logistic Regression)...
echo (Generates model_results.pkl in Dataset/ folder)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_8_model_building.py
goto DONE

:P9
cls
echo Running Practical 9: Model Evaluation...
echo (Generates confusion_matrix.png ^& roc_curve.png in Reports/)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_9_model_evaluation.py
goto DONE

:P10
cls
echo Running Practical 10: Improve Model ^& Comparison...
echo (Generates model_comparison.csv ^& models/best_model.joblib)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_10_improve_model.py
goto DONE

:P11
cls
echo Running Practical 11: Results ^& Conclusion...
echo (Generates predictions.csv in Results/ folder)
echo ------------------------------------------------------------
%PYTHON_CMD% Python_Code\practical_11_results_conclusion.py
goto DONE

:RUN_ALL
cls
echo ============================================================
echo   RUNNING ALL PRACTICALS (1 TO 11) IN SEQUENCE
echo ============================================================
echo.
echo [1/11] Practical 1: Proposal...
%PYTHON_CMD% Python_Code\practical_1_project_proposal.py
echo.
echo [2/11] Practical 2: Dataset Collection...
%PYTHON_CMD% Python_Code\practical_2_dataset_collection.py
echo.
echo [3/11] Practical 3: Understanding Data...
%PYTHON_CMD% Python_Code\practical_3_understanding_data.py
echo.
echo [4/11] Practical 4: EDA...
%PYTHON_CMD% Python_Code\practical_4_eda.py
echo.
echo [5/11] Practical 5: Missing ^& Outliers...
%PYTHON_CMD% Python_Code\practical_5_handle_missing_outliers.py
echo.
echo [6/11] Practical 6: Automated EDA...
%PYTHON_CMD% Python_Code\practical_6_automated_eda.py
echo.
echo [7/11] Practical 7: Feature Selection...
%PYTHON_CMD% Python_Code\practical_7_feature_selection.py
echo.
echo [8/11] Practical 8: Model Building...
%PYTHON_CMD% Python_Code\practical_8_model_building.py
echo.
echo [9/11] Practical 9: Model Evaluation...
%PYTHON_CMD% Python_Code\practical_9_model_evaluation.py
echo.
echo [10/11] Practical 10: Improve Model...
%PYTHON_CMD% Python_Code\practical_10_improve_model.py
echo.
echo [11/11] Practical 11: Results ^& Conclusion...
%PYTHON_CMD% Python_Code\practical_11_results_conclusion.py
goto DONE

:RUN_WEB
cls
echo ============================================================
echo   LAUNCHING INTERACTIVE STREAMLIT WEB DASHBOARD
echo ============================================================
echo.
echo App is starting at http://localhost:8501 ...
echo (Press Ctrl + C in this terminal when you want to stop the server)
echo.
%PYTHON_CMD% -m streamlit run app.py
goto DONE

:RUN_CLI
cls
echo ============================================================
echo   INTERACTIVE CLI PREDICTION TOOL
echo ============================================================
echo.
%PYTHON_CMD% Python_Code\predict.py
goto DONE

:RUN_INSTALL
call config.bat
goto MENU

:DONE
echo.
echo ============================================================
echo   Execution complete!
echo ============================================================
pause
goto MENU

:EXIT_APP
cls
echo Thank you for using E-Commerce Return Prediction System.
echo Exiting...
exit /b
