@echo off
title Environment Configuration and Dependency Installer - SYBCA-AI (Sem-III)
cd /d "%~dp0"
color 0A

echo ============================================================
echo   SYBCA-AI (Sem-III) ^| 303 Machine Learning
echo   Environment Configuration ^& Dependency Manager
echo ============================================================
echo.

:: 1. Detect Python
set PYTHON_CMD=py
py -V >nul 2>&1
if not errorlevel 1 goto PYTHON_FOUND

set PYTHON_CMD=python
python -V >nul 2>&1
if not errorlevel 1 goto PYTHON_FOUND

echo [ERROR] Python is not detected on your PC!
echo Please download and install Python (version 3.10 or higher)
echo from https://www.python.org/downloads/
echo Make sure to check the box: "Add Python to PATH" during installation.
echo.
pause
exit /b 1

:PYTHON_FOUND
echo [*] Python Detected:
%PYTHON_CMD% -V
echo.

:: 2. Check and ensure pip is installed
echo [*] Checking pip (Python Package Installer)...
%PYTHON_CMD% -m pip --version >nul 2>&1
if errorlevel 1 (
    echo [!] pip is not installed. Bootstrapping pip now...
    %PYTHON_CMD% -m ensurepip --default-pip
    if errorlevel 1 (
        echo [ERROR] Failed to install pip automatically.
        pause
        exit /b 1
    )
    echo [OK] pip bootstrapped successfully.
) else (
    %PYTHON_CMD% -m pip --version
)
echo.

:: 3. Run Pre-Installation Environment Check
echo ============================================================
echo   [STEP 1/3] VERIFYING INSTALLED PACKAGES ^& VERSIONS
echo ============================================================
echo.
%PYTHON_CMD% Python_Code\check_env.py
echo.

:: 4. Ask User to proceed with Installation / Upgrade
echo ============================================================
echo   [STEP 2/3] INSTALL ^& UPGRADE SCRIPT
echo ============================================================
set do_install=Y
set /p do_install="Proceed with upgrading pip and installing all requirements? [Y/N, default=Y]: "
if /i "%do_install%"=="N" goto POST_CHECK

echo.
echo [*] Upgrading pip to the latest version...
%PYTHON_CMD% -m pip install --upgrade pip
echo.

echo [*] Installing / upgrading packages from requirements.txt...
%PYTHON_CMD% -m pip install -r requirements.txt
echo.

:POST_CHECK
cls
echo ============================================================
echo   [STEP 3/3] POST-INSTALLATION FINAL VERIFICATION
echo ============================================================
echo.
%PYTHON_CMD% Python_Code\check_env.py
if errorlevel 1 (
    echo.
    echo [WARNING] Some packages could not be installed. Please check your internet connection.
    echo.
) else (
    echo.
    echo [SUCCESS] All requirements are valid and ready to run the project!
    echo.
)

set launch_menu=Y
set /p launch_menu="Do you want to launch the project menu (start.bat) now? [Y/N, default=Y]: "
if /i "%launch_menu%"=="N" (
    echo.
    echo Setup complete. You can run start.bat anytime.
    pause
    exit /b 0
)

cls
call start.bat
